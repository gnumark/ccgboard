<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<?include("manual/book.php")?>
<html>
  <head>
	<title>Generic Collectible Card Game</title>
	<link href="default.css" rel="stylesheet" type="text/css">
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  </head>
  <body> <p> Aviso: Esto es una traduccion del dato FAQ del ingles al espanol por un aleman.
  Por esto tengo que disculparme, si hay muchos errores (mas que todo ortograficos). El sentido de la traduccion
  es, darles una primera vista del programa GCCG a la gente, que de repente no
  sabe tanto el ingles y quiere informarse primero en espanol. Unas secciones (como las de Mtg) he dejado en ingles,
   por que no las vi tan importantes o mi conocimiento no bastaba, para traducirlo bien :). 
  Si encuentran errores, por favor, den me una noticia a mi Email matjaek@web.de.
  Espero que les va a gustar la pagina de Gccg y mas que todo el juego SATM!!</p>
	<h1>Contenido</h1>
	<p class=toc>
	  <?create_toc()?>
	</p>

	<h1>Frequently Asked Questions</h1>

	<!-- =================== GETTING STARTED ================== -->
	<h2><?h1("Empezar")?></h2>

	<!-- ==================== -->
	<h3><?h2("Sistema de computadora")?></h3>
	<!-- ==================== -->

	<h4><?h3("Cuantas Mhz?")?></h4>
	Al menos 300 Mhz recomendado.

	<h4><?h3("Cuanta memoria (RAM)?")?></h4>
	Lo mas que posible, al menos 160MB RAM estan recomendados. Son los 
	imagenes, que necesitan arta memoria. El uso de memoria en No-Windows-sistemas
	se puede limitar, mira los /man unlimit (see <tt>man
	  ulimit</tt>).

	<h4><?h3("Cuanto espacio libre del disco duro?")?></h4>
	El Cache de los imagenes puede consumir hasta 1 GB del disco duro. 
	Para No-Windows-sistemas, usa <tt>--nocache</tt> para tu juego. 


	<h4><?h3("Anchura de banda?")?></h4>
	Gccg no necesita mucha anchura de banda, esta testado usando 56K modem-conexion
	y se podia jugar bien. Solo entrando al juego (Log-in) puede necesitar un poco
	mas tiempo.

	<!-- ==================== -->
	<h3><?h2("Grafica")?></h3>
	<!-- ==================== -->

	<h4><?h3("Que es la resolucion recomendada?")?></h4>
	Resolucion 1024x768 o mas esta recomendada, 800x600 todavia pasa, pero
	no es perfecto. Mira tambien <?ref("Como puedo ajustar la ventana?")?>

	<h4><?h3("No veo lo que escribo")?></h4> 
	Tu ventana de GCCG es demasiado grande para tu pantalla. Sube entonces la
	resolucion de tu Windows al 1024x768 o mas, mueve la ventana o usa el
	Full-size-modo (mira el punto siguiente)

	<h4><?h3("Como uso el Full-size-modo?")?></h4>
	Windows: edita el dato (<tt><em>Game.bat</em></tt>) que hace empezar el juego 
	(para SATM el dato se llama Metw.bat, esta en tu archivo de gccg en el disco duro)
	y cambia la siguiente linea (es la ultima linea del documento)
	<br><tt class=code>
	  ccg_client.exe --user %USER% %1 %2 %3 %4 %5 %6 %7 %8 %9  <em>game</em>.xml
	</tt><br>
	con
	<br><tt class=code>
	  ccg_client.exe --full --user %USER% %1 %2 %3 %4 %5 %6 %7 %8 %9  <em>game</em>.xml
	</tt><br>
	<p>
	  (Se agrega entonces --full delante del --user en esta linea)
	  
	  Otras sistemas operativos: empieza el programa usando el orden
	<br><tt class=code>
	  ./<em>Game</em> --full  (Game es tu juego, seria Metw para jugar SATM)
	</tt><br>
	<p>
	  Nota: <tt>Ctrl+Alt+F</tt> cambia la pantalla entre Full-size y Size normal pero solo 
	  funciona con Linux correcto
	<p>
	  Nota: En Windows puedes cambiar la pantalla entre full y ventana usando <tt>Alt+Tab</tt>.

	<h4><?h3("Como puedo ajustar la ventana?")?></h4>
	Esto no es tan facil para hacer. Puedes poner el parametro
	 <tt>--geometry 800x600</tt> para tener resolucion 800x600 por ejemplo. Sigue las
	 instrucciones  <?ref("Como uso el Full-size-modo?")?>
	reemplecando el parametro <tt>--full</tt> con tu resolucion deseada.

	<h3><?h2("Primeros pasos")?></h3>
	<!-- ==================== -->

	<h4><?h3("Estoy al dentro, que hacer ahora?")?></h4>
	Puedes preguntar otra gente presente, que te ayuden. Si no quieres mostrar, que eres nuevo (bueno, 
	ellos van a notarlo, porque tu dibujo es un raton), puedes hacer click con el boton derecho te tu
	raton y probar las cosas del menu que aparece. Usar <tt>F1</tt> en el teclado te muestra una lista 
	de ordenes para usar adicional. Puedes recibir mas informaciones sobre ordenes usando
	<br><tt class=code>
	  /help <em>command</em>
	  <br></tt>
	
	<h4><?h3("No quiero ser un raton!")?></h4>
	Tienes que cambiar tu  <em>avatar</em> (dibujo) entonces. Una lista de dibujos posibles puedes
	encontrar: <a href="misc/avatars.html">here</a>.

	<h4><?h3("Alguna gente tiene texto debajo de su <tt>/whois</tt> info (Quien-es-info)?")?></h4>
	Puedes poner tu propio texto usando <tt>/set plan
	  <em>text to add</em></tt>. (/set plan y despues el texto que tu quieres poner)

	<!-- =================== Client =========================== -->
    <h2><?h1("Client in general")?></h2>

	<h3><?h2("Account")?></h3>
	<!-- ==================== -->

	<h4><?h3("Que es mi contrasena?")?></h4>
	El  client genera una contrasena casual para ti, cuando te registras al juego por primera vez.
	El server ahora lo guarda, despues de tu primera entrada al juego. La contrasena esta guardada
	tambien en tu disco duro. Este tiene que ser la misma, que la del server, por esto no lo cambies
	or borres este dato. Si quieres saber, que contrasena tienes, mira <tt>~/.gccg/<em>Game</em>/password</tt> (o
	<tt>C:\.gccg\<em>Game</em>\password</tt> en Windows). Nota: no necesitas poner tu contrasena cuando
	quieres entrar el juego, el server automaticamente lo compara con la de tu dato en el disco duro.

	<h4><?h3("Voy a reinstalar mi sistema operativo, que tengo que hacer?")?></h4>
	Guarda una copia de tu ordenador <tt>~/.gccg</tt>  (o
	<tt>C:\.gccg</tt> en Windows). Este ordenador contiene tu contrasena y tus mazos.
 

	<h4><?h3("He perdido mi contrasena.")?></h4>
	Avisa al administrador, que te mande tu dato con la contrasena por Email y disculpate por no 
	haber leido la seccion <?ref("Voy a reinstalar mi sistema operativo, que tengo que hacer?")?>

	<h4><?h3("Como puedo cambiar mi nombre en el juego (Nickname)?")?></h4>
	Empieza el juego con tu nuevo nombre querido y pregunta al administrador, que te transfere tus 
	datos de tu viejo al nuevo nombre.

	<h3><?h2("Economia")?></h3>
	<!-- ==================== -->

	<h4><?h3("Tengo que pagar dinero de verdad?")?></h4>
	No, el dinero solo es virtual. Todo es gratuito.

	<h4><?h3("Para que todo esto con el dinero, solo quiero jugar!")?></h4>
	No te preocupes, todo es opcional. Tambien puedes jugar sin comprarte cartas, entonces juegas 
	con cartas, que no posees en tu coleccion, estas cartas se llaman proxies y son como cartas
	prestadas para un juego.

	<h4><?h3("Ya no tengo dinero, como recibo mas?")?></h4>
	a) Ganas dinero ganando y aun perdiendo partidos.<br>
	b) Puedes ganar dinero tambien haciendo apuestas por un partido de otros (Mira
	<tt>$<em>num</em></tt> marcas en las mesas).<br>
	c) Vende tus cartas a otros jugadores.<br>
	d) Colecciona todas las cartas de un set y registralo, vas a recibir una recompensa.

	<h3><?h2("Coleccionar")?></h3>
	<!-- ==================== -->

	<h4><?h3("Why there aren't any fixed packs?")?></h4>
	All fixed decks are included (or are going to be included) as
	sample decks for the game. This leaves you some collecting tasks
	to fill missing cards for the sample decks.

	<h4><?h3("Como puedo comprar cartas promocionales?")?></h4>
	No lo puedes hasta que alguien las tenga para vender. Despues de haber jugado un partido sin 
	proxies tu recibes una carta promocional como recompensa.

	<h3><?h2("Ordenar la coleccion")?></h3>
	<!-- ==================== -->

	<h4><?h3("Como muestro las cartas que poseo?")?></h4>
	Usa
	<br><tt class=code>
	  /select have>0
	  <br></tt>
	o solo usa <tt>/select have</tt> porque <tt>have</tt>
	evalua  a un numero positivo si tienes 1 o mas cartas. Mira tambien, si ya tienes un filtro 
	para el Sealed-game (clik derecho sobre el marco de tu coleccion y escoge "Select display"
	y ahora miras, si hay "Sealed deck" para escoger.

	<h3><?h2("Comprar/Vender cartas")?></h3>
	<!-- ==================== -->

	<h4><?h3("Como pongo cartas a mi lista de querer vender (have-list)?")?></h4>
	No tienes que, el server te lo hace dependiendo de dos cosas:<br>
	1) Todas tus cartas que posees son para negociar.<br>
	2) Si tienes mas cartas que tu  <tt>trade_limit</tt> (limite de negociar), todas las extras son
	para negociar. Al comienzo, el <tt>trade_limit</tt> esta 4 y se puede cambiarlo usando el orden:
	<br><tt class=code>
	  /set trade_limit <em>n</em>
	  <br></tt>
	donde <em>n</em> es tu nuevo <tt>trade_limit</tt>.

	<h4><?h3("Mi <tt>have</tt>-list (lista de querer vender esta todavia vacia?")?></h4>
	El server ahorra anchura de banda reduciendo la lista de negocios posibles antes de mandarla al
	client. Todas las cartas, que no las tienes en tu <tt>/want</tt>-list (lista de querer comprar)
	no estan mandados donde ti. Como vender y comprar son exclusivo, no puedes mirar las cartas, que
	actualmente has puesto para vender, en tu  <tt>/have</tt>-list. Pero puedes ver estas cartas, si
	tienes mas que tu  <tt>trade_limit</tt> y si todavia quieres tener mas de estas.

	<h3><?h2("Mazos")?></h3>
	<!-- ==================== -->

	<h4><?h3("Como uso proxies?")?></h4>
	Solo pon cartas que no las posees a tu mazo. En tu lista de este mazo estan marcadas con un
	numero rojo.<br>
	Nota: Tendras que ponerte de acuerdo con tu adversario antes del partido, si estas usando proxies.

	<h4><?h3("He exportado un mazo pero no puedo encontrarlo?")?></h4>
    Mira <tt>C:\.gccg\<em>Game</em>\export</tt> (Windows) o <tt>~/.gccg/<em>Game</em>/export/</tt> (no-Windows).

	<h4><?h3("How do i import an existing deck?")?></h4>
	Write a simple text file where you put line by line number of
	each card and the card name. If your deck has more sections than
	just a main deck, add section names without any preceding
	number. You can check the examples in the directory
	<tt>decks/<em>Game</em>/</tt>. When your deck is ready, put it to
	your <tt>import</tt> directory which is at the same subtree as
	your <tt>export</tt> directory (See 
	<?ref("I exported a deck but i can't find it?")?>) After that you
	can try importing it (<tt>Ctrl+I</tt>).
	<p>
	  Tip: Don't copy any Gccg comment headers from the sample
	  decks. Without them, the client tries harder to resolve unrecognized card
	  names. Otherwise it assumes a Gccg-exported deck with precisely
	  correct card names.
	<p>
	  Note: Gccg supports also other deck formats like NetMECCG and
	  Apprentice and those decks are importable without any modifications.

	<h3><?h2("Jugar")?></h3>
	<!-- ==================== -->

	<h4><?h3("Puedo jugar juegos Sealed (Sealed games)?")?></h4>
	Si, prueba <tt>/help sealed</tt>.

	<h4><?h3("Como puedo unir dos cartas?")?></h4>
	Para unir una carta con otra, mueve la flecha del raton sobre la carta, que quieres unir. 
	Ahora apreta la tecla <tt>Control</tt>, y no la sueltes. Apretando <tt>Control</tt>, haz klik izquierda 
	con el raton y no lo sueltas el boton y mueve el raton sobre la carta destino (la con que quieres 
	unir la primera carta). Llegando ahi, puedes soltar el boton del raton y la tecla <tt>Control</tt>.

	<h3><?h2("Tricks and Tips")?></h3>
	<!-- ==================== -->

	<h4><?h3("How can i restore collection default view?")?></h4>
	You can bind an menu option <em>Select Display.../Default</em> to a key by
	<br><tt class=code>
	/bind /eval SetBookIndex("default","default")
	  <br></tt>
	and pressing the target key.

	<!-- =================== MTG ============================== -->
	<h2><?h1("Mtg")?></h2>

	<h3><?h2("Playing")?></h3>
	<!-- ==================== -->

	<h4><?h3("How can i alter my life points?")?></h4>
	You can set the life to the specified <em>n</em> by simply typing
	<tt><em>n</em></tt> and pressing Enter. You can also increase it
	by the specified amount by preceding the number with <tt>+</tt>
	sign or	decrease it by preceding with <tt>-</tt> sign.

	<h4><?h3("I try to say a number, but my life changes? That sucks.")?></h4>
	Add one space before or after the number.

	<h3><?h2("Specific cards")?></h3>
	<!-- ==================== -->

	<h4><?h3("Cursed Scroll.")?></h4>
	You name a card (<tt>Ctrl+middle click</tt> over the card and
	press enter) and
	shuffle your hand (<tt>Ctrl+S</tt> over your hand). Then
	your opponent left clicks your hand to expand it to the full
	size and chooses from the menu "Reveal card" over the chosen card.

	<h4><?h3("Hymn to Tourach.")?></h4>
	Left click the opponent's hand to expand it to the full size and
	shuffle it (<tt>Ctrl+S</tt> over the hand). Then select "Force
	discard" twice over the selected cards.

	<h4><?h3("Future Sight.")?></h4>
	Just reveal your deck (<tt>Ctrl+F</tt> over your deck). It shows
	the topmost card all the time then.

	<h3><?h2("Rules")?></h3>
	<!-- ==================== -->

	<h4><?h3("What is Tribal War?")?></h4>
	Tribal War has three variants: T1, T1.5 and Ante. The rules are the same
	as normal T1, T1.5 or Ante, but your deck must contain 33% creatures
	having the same type. Creatures having more than one type, counts
	toward any of the types it have. Following cards are restricted to one in the
	T1 variant: <em>An-Zerrin Ruins</em>, <em>Engineered Plague</em>,
	<em>Extinction</em> and <em>Coat of Arms</em>. The cards are
	banned in the T1.5 variant. In the Ante variant there are no
	additional restrictions.


	<!-- =================== METW ============================= -->
	<h2><?h1("SATM")?></h2>

	<h3><?h2("General")?></h3>
	<!-- ==================== -->

	<h4><?h3("Sobres Balrog?")?></h4>
	Era una decision de los jugadores, que han probado el juego. Dos mazos fijos no estan hecho para
	coleccionar, sobres con cartas casuales se entienden mucho mejor con la idea del programilla GCCG, 
	coleccionar cartas.

	<h4><?h3("De donde saben la raridad de las cartas del sobre balrog?")?></h4>

	Toma los dos cajas Balrog y cuenta las cartas. Asi tienes la raridad de cada carta en la edicion
	Balrog. 

	<h3><?h2("Mazos")?></h3>
	<!-- ==================== -->

	<h4><?h3("How to build 2 different hazard decks?")?></h4>
	Haz dos  versiones del mismo mazo con advesidades differentes. Puedes hacer tambien 3 mazos:
	mazo commun, mazo contra minions, mazo contra hero. Antes de jugar, usa el orden 
	<tt>/newdeck play</tt> y junta las cartas que necesitas usando el orden "Add cards from another
	deck..." del menu. Esto es un poco mas trabajo antes de jugar, pero despues lo hace mas facil, 
	cambiar partes de las cartas.

	<h3><?h2("Jugar")?></h3>
	<!-- ==================== -->

	<h4><?h3("Se termino el mazo, que hacer?")?></h4>
	Pon la pila de descartes boca abajo (<tt>Ctrl+F</tt>) si estaba boca arriba. Mira a tu pila de 
	descartes (<tt>Ctrl+L</tt>) y apreta la tecla <tt>Home</tt> sobre todos los sitios en tu pila 
	de descartes. Ahora escoge 5 cartas de tu pila de descartes y pon las a la pila adicional. 
	Para esto haces clik derecho sobre cada de las 5 y escoges "Put to sideboard". Ahora cierra la
	pila de descartes con <tt>Esc</tt> y mira a tu pila adcicional (Sideboard) (con clik izquierda
	o  las teclas <tt>Ctrl+L</tt>). Apreta  <tt>Delete</tt> sobre cada carta (maximal 5), que quieres
	poner a tu mazo normal. Ahora cierra tu mazo adicional con ESC y regresa a al pila de descartes.
	Haz clik derecho sobre la y escoge "Shuffle to the deck" (lo mezcla al mazo). No olvides, ponerla
	de nuevo boca arriba, si el juego lo demanda.

	<h3><?h2("Cartas especificas")?></h3>
	<!-- ==================== -->

	<h4><?h3("Aware of their Ways.")?></h4>
	 El adversario mezcla su pila de descartes con las teclas (<tt>Ctrl+S</tt>) y pone ahora las primeras
	 4 cartas al lado con la tecla <tt>End</tt>. Ahora el pone estas 4 cartas boca arriba (<tt>Ctrl+F</tt>).
	 Tu puedes ahora escoger una carta con <tt>ctrl+middle click</tt> apretas <tt>Enter</tt>),para que la
	 carta escogida se salga del juego. El adversarion descarta con <tt>Delete</tt> las demas 3 cartas.

	<h4><?h3("Barrow-blade.")?></h4>
	Para recibir los puntos correctos de los objetos, puedes apretar <tt>Ctrl++</tt> sobre la carta
	<em>Dagger of Westernesse</em> y apretas  <tt>Ctrl+-</tt> sobre la carta <em>Barrow-blade</em>.

	<h4><?h3("Goblin Faces.")?></h4>
	Apreta la tecla <tt>End</tt> sobre el mazo de tu adversario, para que sus cartas del mazo vayan al lado.
	Ahora juegalas una por una con boca abajo. (usando clik derecho y el menu, que aparece). Para cada
	carta le dices al adversario, si la tiene que poner arriba  o abajo del mazo. Para hacer esto,
	el adversario apreta la tecla <tt>Home</tt> para poner la carta al arriba del mazo, y las teclas
	<tt>Ctrl+Home</tt> para poner la carta abajo del mazo.

	<h4><?h3("Secret News.")?></h4>
	Haz clik izquierda sober la mano de tu adversario, para agrandarla. Mezcla la mano con las teclas 
	<tt>Ctrl+S</tt> y haz clik derecho sobre 5 cartas, escogiendo el orden "Reveal card" del menu, que
	aparece.

	<!-- =================== SERVER =========================== -->
	<h2><?h1("Server")?></h2>

	<!-- =================== CONTRIBUTING ===================== -->
	<h2><?h1("Contributing")?></h2>

	<h3><?h2("Graficas")?></h3>
	<!-- ==================== -->

	<h4><?h3("Puedo dibujar mi propio dibujo (avatar)?")?></h4>
	Si, dibujate un avatar, cumpliendo las especificaciones (mira abajo) y pon lo al ordenador
	 <tt>graphics/avatar</tt> en tu computadora para probarlo. Si se ve bien, mandalo al administrador
	 para que lo instale al server.

	<h4><?h3("Que son las especificaciones para los dibujos?")?></h4>
	Dato PNG (PNG-files), tamano 32x32, negro puro (R,G,B = 0,0,0) no es visible. El dibujo no debe
	violar el Copyright y el buen gusto.
	<p>
  </body>
</html>

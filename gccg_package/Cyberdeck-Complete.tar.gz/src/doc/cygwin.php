<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<?
// Return list of files matching regular expression (without //).
function FilesMatching($dir,$rexp)
{
	$ret=array();

	$d=@opendir($dir);
	if($d)
		while (($f = readdir($d))!==false)
		{
			if(preg_match("/".$rexp."/",$f))
				array_push($ret,$f);
		}

  sort($ret);

	return $ret;
}

function FindFile($pattern)
{
  $f=FilesMatching(".",$pattern);
  rsort($f);
  return $f[0];
}

function FindFileDir($dir,$pattern)
{
  $f=FilesMatching($dir,$pattern);
  rsort($f);
  return $f[0];
}

function LinkTo($pattern)
{
	$f=FindFile($pattern);
	if($f=="")
		echo "<font color=red>UNAVAILABLE</font>\n";
	else
		echo "<a href=\"$f\"><tt>$f</tt></a>\n";
}

function LinkToDir($dir,$pattern)
{
	$f=FindFileDir($dir,$pattern);
	if($f=="")
		echo "<font color=red>UNAVAILABLE</font>\n";
	else
		echo "<a href=\"$dir/$f\"><tt>$f</tt></a>\n";
}

?>
<html>
  <head>
    <title>Generic Collectible Card Game</title>
    <link href="default.css" rel="stylesheet" type="text/css"></link>
  </head>
  <body>
	
	<h1>Cygwin guide</h1>
	<h3>A Brief HOWTO on Running GCCG via Cygwin (for Windows-Dummies ;)</h3>

	<ul>
	  <li>First, download the file <a
	  href="http://www.cygwin.com/setup.exe">http://www.cygwin.com/setup.exe</a>
	  and run it.

	  <li>Choose "Install from Internet"

	  <li>You'll be given some options on where to install Cygwin etc,
	  and then a list of mirrors from which to download. Just choose
	  the one closest to you (there's Sunet.se for Finnish people).

	  <li>Then you'll be given a list of components that will and will
	  not be installed. Check that all categories are on 'Default' and
	  then click 'View' to change it to 'Full'. Scroll down until you
	  see the '<tt>perl</tt>' and '<tt>wget</tt>' packages and make sure they will be
	  installed (click on them).

	  <li>The setup will download and install (or just download if you
	  chose to) the files and inform you when it's done.

	  <li> Run the <tt>cygwin.bat</tt> and type:
	  <pre>
mkdir gccg
cd gccg
wget <? echo "http://gccg.sourceforge.net/modules/".FindFileDir("modules","gccg-core.*")."\n";?>
tar xzf <? echo FindFileDir("modules","gccg-core.*")."\n";?>
	</pre>

	<li>
		Now you'll have the basis of gccg installed and after this you
		only need to use the gccg_package to update the client. Type:<br>

  <tt>./gccg_package status</tt>

<li> You'll see the list of packages which are (or aren't at this
time) installed to you. To install, type:<br>

<tt>./gccg_package install client windows32 fonts-windows</tt><br>

After the script completes, you will have the full Windows-client (check <tt>./gccg_package status</tt>).

<li>
Now you just have to download the games that you wish to play. For MtG:<br>

<tt>./gccg_package install mtg</tt>
</ul>

<p>

You will now have the GCCG installed in
<tt>C:\Cygwin\home\[username]\gccg\</tt> (by default) and you can run
it as you normally would (<tt>Mtg.bat</tt> for MtG etc.).
Later, when you want to update your client, apply <tt>./gccg_package update</tt>. <b>Note:</b> You may need to do <tt>chmod a+x *</tt> again if windows binary package <tt>windows32</tt> is updated. See "Common Problems".

<h3>Common Problems</h3>
<ul>
<li>If you encounter <em>"The application fails to initialize properly"</em> you may try saying<br>
<tt>chmod a+x *</tt><br>
under Cygwin in install directory.
<li>Sometimes it seems that for some reason the game <tt>.bat</tt> file does not work by doubleclicking it. You can also try to launch the game from cygwin using command: <br><tt>sh Mtg --user nickname</tt>.
</ul>

    <hr>

    <address>Snaga</address>
<!-- Created: Thu Jan 30 12:51:11 EET 2003 -->
<!-- hhmts start -->
Last modified: Fri Jan 31 01:00:50 EET 2003
<!-- hhmts end -->

  </body>
</html>

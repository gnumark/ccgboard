<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//IT" "http://www.w3.org/TR/html4/loose.dtd">
<html>
  <head>
    <title>Generic Collectible Card Game</title>
    <link href="default.css" rel="stylesheet" type="text/css">
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  </head>
<?
// Return list of files matching regular expression (without //).
function FilesMatching($dir,$rexp)
{
	$ret=array();

	$d=@opendir($dir);
	if($d)
		while (($f = readdir($d))!==false)
		{
			if(preg_match("/".$rexp."/",$f))
				array_push($ret,$f);
		}

  sort($ret);

	return $ret;
}

function FindFile($pattern)
{
  $f=FilesMatching(".",$pattern);
  rsort($f);
  return $f[0];
}

function FindFileDir($dir,$pattern)
{
  $f=FilesMatching($dir,$pattern);
  rsort($f);
  return $f[0];
}

function LinkTo($pattern)
{
	$f=FindFile($pattern);
	if($f=="")
		echo "<font color=red>UNAVAILABLE</font>\n";
	else
		echo "<a href=\"$f\"><tt>$f</tt></a>\n";
}

function LinkToDir($dir,$pattern)
{
	$f=FindFileDir($dir,$pattern);
	if($f=="")
		echo "<font color=red>UNAVAILABLE</font>\n";
	else
		echo "<a href=\"$dir/$f\"><tt>$f</tt></a>\n";
}

?>
  <body>
	  <center>
		<a href="modules/"><img alt="Gccg" class="photo" src="logo.png"></a>
	  </center>
  <img class="photo" src="uk.jpg"> <strong>English version available <a href="index.php">here</a></strong>

	  <h1>Introduzione</h1> Generic Collectible Card Game &egrave;
	  l'implementazione di un motore per giochi di carte multiplayer
	  e multipiattaforma.Il motore di gioco &egrave; sviluppato in
	  modo da essere composto da un nucleo indipendente di uso generale
	  e da vari moduli che definiscono ognuno un ambiente di gioco diverso.
	  I giocatori devono scaricare solo il client per la loro piattaforma
	  e i moduli dei giochi a cui sono interessati. Dopo aver lanciato il
	  client per uno dei giochi, esso si collega al server centrale del
	  gioco scelto.
	  Una volta connessi, tutti le caratteristiche del gioco sono a disposizione
	  del giocatore:
	  <ul>
		<li>Editor dei mazzi con importazione/esportazione da file di testo.
		<li>giocabilit&agrave; veloce: l'arbitraggio automatico non &egrave;
		implementato (per scelta).
		<li>da 1 a 4 giocatori.
		<li>Puoi guardare le partite degli altri, mentre non stai giocando.
		<li>Altamente personalizzabile:sono supportati macros e scripting.
		<li>I server supportano diverse modalit&agrave; di gioco (per esempio Type 1,
		Type 1.5, etc. in Mtg). Possono essere definite modalit&agrave; di gioco personalizzate.
		<li>Vendita delle carte della collezione determinando prezzo e numero di carte in vendita.
		I client permettono di visualizzare sempre l'offerta migliore.
		<li>Scambio facilitato: crea la tua "want list" e il server ti aiuta a scambiare con gli
		altri giocatori.
		<li>Sealed deck games.
		<li>Importa ed esporta da formati di file gi&agrave; esistenti.
	  </ul>

	<h1>Storia</h1>
		<ul>
		<li><strong>25/01/2001</strong>: Inizio del progetto.
		<li><strong>09/01/2002</strong>: Viene giocata la prima partita completa di Mtg.
		<li><strong>18/09/2002</strong>: Viene giocata la prima partita completa di Pokemon.
		<li><strong>04/12/2002</strong>: Viene giocata la prima partita completa di Metw.
		<li><strong>25/01/2003</strong>: Primo annuncio pubblico su happypenguin.org.
		<li><strong>29/01/2003</strong>: Il progetto si sposta su gccg.sourceforge.net.
		<li><strong>26/09/2003</strong>: Viene giocata la prima partita completa di Lotr.
		</ul>

	<h1>Screenshots</h1>

	  Clicka su un'immagine per ingrandirla.<p>
<?
	$files=FilesMatching(".","thumb*.*\.jpg");
	foreach($files as $f)
	  echo "<a href=\"".preg_replace("/thumb/","screenshot",$f)."\"><img class=\"photo\" alt=\"screenshot\" src=\"$f\"></a>\n";
?>
	<p>
	<strong>NOTA: Le immagini delle carte non sono comprese nel gioco.</strong>

	<h1>Installazione</h1>

	  <h2>Linux</h2>

	  <ul>
		<li>Crea la directory per il gioco<br>
		  <tt>mkdir gccg</tt><br>
		  <tt>cd gccg</tt><br>

		<li>Scarica <? echo LinkToDir("modules","gccg-core.*");?>
		nella directory che hai appena creato e scompattalo.
		<br>
		  <tt>tar xzvf <? echo FindFileDir("modules","gccg-core.*");?></tt>

		<li>Ora puoi usare il package manager <tt>gccg_package</tt> per installare il resto del gioco;
		devi installare almeno <tt>client</tt>, <tt>fonts</tt> e <tt>linux-i386</tt>
		<br>
		  <tt>./gccg_package install client fonts linux-i386</tt>
		<li>Puoi visualizzare la lista dei pacchetti disponibili
		<br>
		  <tt>./gccg_package status</tt>

		<li>Installa i moduli dei giochi che intendi giocare
		<br>
		  <tt>./gccg_package install <em>gioco</em></tt><br>
		  dove <tt><em>gioco</em></tt> &egrave; uno qualsiasi tra <tt>mtg</tt>, <tt>pokemon</tt>, <tt>lotr</tt> o <tt>metw</tt>.

		  <li>Ogni modulo di gioco ha uno script di avvio con lo stesso nome del gioco, con la prima lettere maiuscola.
		  Per esempio puoi lanciare mtg semplicemente digitando<br>
		  <tt>./Mtg</tt>

		<li>Per aggiornare tutti i pacchetti installati scrivi<br>
		  <tt>./gccg_package update</tt>
	  </ul>

	  <h2>Mac OS X</h2>

	  Per installare Gccg su Mac OS X ci vuole una certa familiarit&agrave; con il Terminale e la modalit&agrave; testuale dei comandi.
	  <ul>
		<li> Avvia il terminale (che trovi in /Application/Utilities/).</li>
		<li>Crea una cartella dove installare GCCG:
		<br>
		  <tt>mkdir gccg</tt></li>
		<li>Spostati nella cartella con il comando:
		<br>
		  <tt>cd gccg</tt></li>
		<li>Scarica<? echo LinkToDir("modules","gccg-core.*");?> digitando: <br>
		  <tt>curl -O http://gccg.sourceforge.net/modules/<? echo FindFileDir("modules","gccg-core.*");?></tt></li>
		<li>Scompatta il file che hai appena scaricato con:<br>
		  <tt>tar xzvf <? echo FindFileDir("modules","gccg-core.*");?></tt></li>
		<li>Installa i pacchetti necessari per il client:
		<br>
		  <tt>./gccg_package install client fonts macosx</tt></li>
		<li>Installa i moduli dei giochi a cui vuoi giocare con gccg:<br>
		  <tt>./gccg_package install <em>gioco</em></tt><br>
		  dove <tt><em>gioco</em></tt> &egrave; uno qualsiasi tra <tt>mtg</tt>, <tt>pokemon</tt>, <tt>lotr</tt> o <tt>metw</tt>.
		<li>Avvia il gioco digitando:<br>
		  <tt>./<em>Gioco</em></tt><br>
		  dove <tt><em>Gioco</em></tt> &egrave; <tt>Mtg</tt>, <tt>Pokemon</tt>, <tt>Lotr</tt> o <tt>Metw</tt>.
	  </ul>
	  <h3>Note:</h3>
	  <ul>
		<li>Se hai un mouse con un solo tasto puoi usare alt+click invece del tasto centrale e ctrl+alt+click invece di ctrl+tasto centrale.</li>
		<li>Se vuoi, puoi anche scrivere <tt>/bind /eval MouseMiddleClick()</tt> e quindi premere un <em>tasto</em>. Da ora in poi, premere quel <em>tasto</em> equivale a usare il tasto centrale del mouse.</li>
        <li>Alcuni dei simboli speciali non vengono prodotti correttamente su OS X. puoi usare il comando <tt>/bindk</tt> (vedi <tt>/help bindk</tt> nel client di gioco) per collegare un tasto a quei simboli. Vedi la sezione "Text formatting" del <a href="manual/">manuale</a> (ancora solo in inglese) per altre informazioni sui simboli speciali.
	Nota che quando usi un carattere speciale non puoi vederlo finch&eacute; non hai digitato l'intero tag. <br><strong>Per esempio</strong>: digita <tt>/bindk {R}</tt> e premi invio. Quindi premi una combinazione di tasti. Ora puoi produrre il simbolo del mana rosso premendo quella combinazione di tasti.
	  </ul>

	  <h2>Sorgenti</h2>
	  <ul>
		<li>Assicurati di avere tutte le librerie (inclusi gli headers):
		  <a href="http://www.libsdl.org/download-1.2.php">SDL</a>,
		  <a href="http://www.libsdl.org/projects/SDL_image/">SDL_image</a>,
		  <a href="http://www.libsdl.org/projects/SDL_net/">SDL_net</a> e
		  <a href="http://www.libsdl.org/projects/SDL_ttf/">SDL_ttf</a>.
		<li>Installa il modulo <? echo LinkToDir("modules","gccg-core.*");?>
		come descritto sopra. Quindi, invece dei binari, installa i sorgenti
		<br>
		 <tt>./gccg_package install client fonts source</tt>
		<li>Compila<br> <tt>./configure</tt><br>
		<tt>make</tt><br>
		<li>Continua come sopra e installa i moduli di gioco.
	  </ul>
		Il codice sorgente &egrave; anche disponibile <a><? echo LinkToDir("modules","gccg-source.*");?>qui</a>.

	  <h3>Note:</h3>
	  <ul>
		<li>I sorgenti non compilano con Gcc 3.1. Per lo meno alcune versioni hanno problemi con mappe che coinvolgono puntatori a funzioni templated member.
		Comunque potete installare anche diverse versioni dun compilatore sul vostro sistema. Abitualmente il compilatore aggiuntivo si chiama <tt>gcc2</tt> o <tt>gcc-3.2</tt>.
		Potete utilizzare il compilatore aggiuntivo settando le variabili d'ambiente <tt>CC=gcc2</tt>, <tt>CXX=g++2</tt> e <tt>LD=g++2</tt> prima del <tt>./configure</tt>.</li>
	  </ul>

	  <h2>Windows</h2>

		Se sei interessato allo sviluppo puoi installare Gccg con Cygwin come spiegato nella
	  <a href="cygwin_it.php">Guida a Cygwin</a>. Altrimenti scarica semplicemente <a href="gccg_install.zip">l'installer per Windows</a>. Scompatta tutti i file e avvia l'installer chiamato<p> <tt>Install <em>Gioco</em>.bat</tt><p>
	Esso scarica e installa tutti i moduli di Gccg necessari per giocare a quel particolare <em>Gioco</em>
	<br>
	dove <tt><em>Gioco</em></tt> &egrave; <tt>Mtg</tt>, <tt>Pokemon</tt>, <tt>Lotr</tt> o <tt>Metw</tt>.
	Per giocare, avvia
        <p><tt><em>Gioco</em>.bat</tt><p>
	e segui le istruzioni sullo schermo.
	Per aggiornare tutti i moduli installati, lancia lo script di aggiornamento chiamato <p><tt>Update Everything.bat</tt> (GCCG &egrave; in pieno sviluppo e viene spesso aggiornato).<p>

	  <h2>Other</h2>

	  <ul>
	  <li>Non disponibile per altre piattaforme. Dovrebbe compilare su qualsiasi sitema con SDL installato.
	  </ul>

	  <h1>Documentazione</h1>

	  Aiuto online su IRCNet: <tt>/join #gccg</tt>.
	  <p>
	  <a href="faq.php">FAQ</a>
	  <p>
	  Naviga il <a href="manual">reference manual</a>.

	  <h1>Servers</h1>

	  <strong><a href="https://gandalf.humppa.jyu.fi/ccg/">gandalf.humppa.jyu.fi</a></strong> (mtg,pokemon,metw,lotr) Server per sviluppatori e playtester.
	  <p>

	  Per aggiungere un server in questa sezione puoi contattare l'autore.
      <h1>Links</h1>
	  <h4>Gccg</h4>
	  <a href="http://sourceforge.net/forum/?group_id=72744">Gccg-Forum</a><br>
	  <a href="http://sf.net/projects/gccg/">SourceForge Project Page</a><br>
	  <a href="http://lists.sourceforge.net/lists/listinfo/gccg-devel">Mailing list</a><br>
	  <a href="http://gccg.sourceforge.net/misc/avatars.html">Avatars</a><br>
	  <h4>Mtg</h4>
	  <a href="http://www.crystalkeep.com/magic/">Fonte di informazioni su Mtg</a><br>
	  <h4>Metw</h4>
	  <a href="http://www.meccg.net/netherlands/meccg/index.html?rules.html">Regole di Metw</a><br>

	  <h1>Autori</h1>
	  <h4>Codice</h4>

	  Tommi Ronkainen

	  <h4>Contributi vari</h4>

	  Antti Kantola, Aaron, Ilja Savolainen, Richard R. Buonanno, Napsu, Aleksi Keurulainen, Malakh Harbonah,
 Peter van Hardenberg, Jukka Karvonen, Antonio Cardenas, Jani Pietik�inen, FaUsT, Jonas Jermann, Pierre Bureau, Joshua Delahunty,
Petteri Nurmesj�rvi, Dyami Serna, Gerard Glaser, Bannor, Peter Minten, Dario Carlentini, Kuba Krchak, Dark, Grilled Fish, Kris Van Beurden, Ilkka Launonen.

	  <h4>Playtesting</h4>

	  Petteri Nurmesj�rvi, Ilja Savolainen, Veli Maaranen, Aleksi Keurulainen, Jukka Karvonen, Antti Kantola, Tommi Aittola, Lavapunk, Wim Heemskerk, Timo Tuomainen

	  <h4>Special thanks</h4>

	  Andre Arko and Tom Hackett (per avermi dato accesso a OS X).
	  <hr>
<A href="http://sourceforge.net"> <IMG class="photo" src="http://sourceforge.net/sflogo.php?group_id=72744&amp;type=5" width="210" height="62" border="0" alt="SourceForge.net Logo"></A>
<!-- Created: Fri Aug 23 17:23:44 EEST 2002 -->
<!-- hhmts start -->
Ultima modifica: Gioved� 23/10 09:14:17 CEST 2003
<!-- hhmts end -->
	  </body>
</html>

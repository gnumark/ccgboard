#!/usr/bin/env ruby

# This script outputs a html table which shows all avatars and their names. 
# Place this file in the doc directory of gccg and run it with 
# ./make_avatars_listing.rb, it will generate or overwrite 'avatars.html'.

output = "<html><head><title>GCCG Avatars</title></head><body>"+
	 "<h2>Avatars</h2>"+
	 "This table lists all the avatar images currently in GCCG.<br>" +
         "To change your avatar image type in GCCG:<br> '<tt>/set avatar " +
         "<i>avatar_name</i></tt>' <br> where <i>avatar_name</i> is one of the " +
         "names in the table."

output += "<table border='1'>"

done = false;

l = Dir["../graphics/avatar/*.png"]
j = 0

until done do
  output += "<tr>"
  for i in 1..4 do
    if j >= l.length - 1 then
      done = true
      break
    else
      j += 1
      l[j] =~ /\/[A-Za-z0-9_]*\./
      if $& then
        output += "<td>#{$&[1..$&.length-2]}</td><td><img src='#{l[j]}'></td>"
      end
    end
  end
  output += "</tr>"
end

#Dir["graphics/avatar/*"].each{|name|
#  name =~ /\/[A-Za-z0-9_]*\./
#  output += "<tr><td>#{$&[1..$&.length-2]}</td><td><img src='#{name}'></td></tr>"
#}

output += "</table></body></html>"

open("avatars.html","w"){|file|
  file.write output
}

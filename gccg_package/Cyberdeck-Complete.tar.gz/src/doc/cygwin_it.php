<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//IT" "http://www.w3.org/TR/html4/loose.dtd">
<?
// Return list of files matching regular expression (without //).
function FilesMatching($dir,$rexp)
{
	$ret=array();

	$d=@opendir($dir);
	if($d)
		while (($f = readdir($d))!==false)
		{
			if(preg_match("/".$rexp."/",$f))
				array_push($ret,$f);
		}

  sort($ret);

	return $ret;
}

function FindFile($pattern)
{
  $f=FilesMatching(".",$pattern);
  rsort($f);
  return $f[0];
}

function FindFileDir($dir,$pattern)
{
  $f=FilesMatching($dir,$pattern);
  rsort($f);
  return $f[0];
}

function LinkTo($pattern)
{
	$f=FindFile($pattern);
	if($f=="")
		echo "<font color=red>UNAVAILABLE</font>\n";
	else
		echo "<a href=\"$f\"><tt>$f</tt></a>\n";
}

function LinkToDir($dir,$pattern)
{
	$f=FindFileDir($dir,$pattern);
	if($f=="")
		echo "<font color=red>UNAVAILABLE</font>\n";
	else
		echo "<a href=\"$dir/$f\"><tt>$f</tt></a>\n";
}

?>
<html>
  <head>
    <title>Generic Collectible Card Game</title>
    <link href="default.css" rel="stylesheet" type="text/css"></link>
  </head>
  <body>

	<h1>Guida a Cygwin</h1>
	<h3>Un breve HOWTO su come far funzione GCCG sotto Cygwin (per Windows-Dummies ;)</h3>

	<ul>
	  <li>Per prima cosa scarica <a href="http://www.cygwin.com/setup.exe">http://www.cygwin.com/setup.exe</a>
	  e avvialo.
	  <li>Scegli "Install from Internet"

	  <li>Ti verranno proposte varie opzionisu dove installare Cygwin etc...,
	  e una lista di mirror da cui scaricare. Scegli quello che ti &egrave; pi&ugrave; vicino
	  (per l'Italia &egrave; ftp.univie.ac.at ).

	  <li>Quindi ti viene proposta una lista di componenti da installare o meno.
	  Controlla che tutte le categorie siano su 'Default' e clicka quindi
	  su 'View' e seleziona 'Full'. Scorri la schermata fino a che non trovi i pacchetti
	  '<tt>perl</tt>' e '<tt>wget</tt>' e assicurati che siano tra quelli che verranno installati
	  (selezionali clickandoci sopra).

	  <li>Il setup scaricher&agrave; e installer&agrave; (o scaricher&agrave; soltanto
	  se hai scelto questa opzione) i file e ti dir&agrave; quando il processo &egrave; completato.

	  <li> Avvia <tt>cygwin.bat</tt> e digita:
	  <pre>
mkdir gccg
cd gccg
wget <? echo "http://gccg.sourceforge.net/modules/".FindFileDir("modules","gccg-core.*")."\n";?>
tar xzf <? echo FindFileDir("modules","gccg-core.*")."\n";?>
	</pre>

	<li>
		Ora hai il modulo base di gccg installato e devi solo
		usare gccg_package per aggiornare il client. Digita:<br>

  <tt>./gccg_package status</tt>

<li> Vedrai l'elenco dei moduli installati (o da installare) sul tuo computer. Per installare, digita:<br>

<tt>./gccg_package install client windows32 fonts-windows</tt><br>

Appena finito di scaricare, avrai il tuo client installato (controlla con <tt>./gccg_package status</tt>).

<li>
Ora devi solo scaricare i moduli per i giochi a cui vuoi giocare. Per MtG:<br>

<tt>./gccg_package install mtg</tt>
</ul>

<p>

A questo punto avrai GCCG installato su
<tt>C:\Cygwin\home\[username]\gccg\</tt> (questo &egrave; l'installazione tipo) e puoi avviarlo semplicemente
usando il giusto script (<tt>Mtg.bat</tt> per MtG etc...).
Quando vorrai aggiornare il tuo client usa <tt>./gccg_package update</tt>. <strong>Nota:</strong>
Potresti dover digitare di nuovo <tt>chmod a+x *</tt> di nuovo se aggiorni il modulo dei binari per Windows "<tt>windows32</tt>". Vedi "Problemi comuni".

<h3>Problemi comuni</h3>
<ul>
<li>Se sullo schermo compare <em>"The application fails to initialize properly"</em> puoi provare a digitare<br>
<tt>chmod a+x *</tt><br>
nella directory dove hai installato il gioco.
<li>Sembra che, in alcuni casi, per qualche ragione il file <tt>.bat</tt> non funzioni clickandoci semplicemente sopra. Puoi avviarlo usando cygwin con questo comando:
<br>
<tt>sh Mtg --user nickname</tt>.
</ul>

    <hr>

    <address>Snaga</address>
<!-- Created: Thu Jan 30 12:51:11 EET 2003 -->
<!-- hhmts start -->
Last modified: Fri Jan 31 01:00:50 EET 2003
<!-- hhmts end -->

  </body>
</html>

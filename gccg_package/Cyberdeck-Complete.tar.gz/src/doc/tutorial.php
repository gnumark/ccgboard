<?
function FilesMatching($dir,$rexp)
{
	$ret=array();

	$d=@opendir($dir);
	if($d)
		while (($f = readdir($d))!==false)
		{
			if(preg_match("/".$rexp."/",$f))
				array_push($ret,$f);
		}

  sort($ret);

	return $ret;
}
function FindFileDir($dir,$pattern)
{
  $f=FilesMatching($dir,$pattern);
  return $f[0];
}
function LinkToDir($dir,$pattern)
{
	$f=FindFileDir($dir,$pattern);
	if($f=="")
		echo "<font color=red>UNAVAILABLE</font> ";
	else
		echo "<a href=\"$dir/$f\"><tt>$f</tt></a> ";
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
  <head>
    <title>Gccg Tutorial</title>
    <link href="default.css" rel="stylesheet" type="text/css"></link>
  </head>
  <body>
    <h1>Gccg Tutorial</h1>


	<h2>1. Installation</h2>
	<pre>
First download <? echo LinkToDir("modules","gccg-core.*");?> from gccg.sf.net
Second move the file to game directory (e.g. ~/Programs/GCCG)
Third in the command prompt type:
	cd [game directory]
	tar xzvf <? echo FindFileDir("modules","gccg-core.*")."\n";?>
Now use packagemanager to download and install mandatory  packages
	cd [game directory]
	./gccg_package install client fonts linux-i386
Now install game modules:
	./gccg_package status   <----Lists available packages
	./gccg_package install [game]
Now run the game
	./[Capitolized  game name (e.g. Mtg )] --user [Preffered Username]
	</pre>

	<h2>2. Customizing</h2>
	<pre>
1. If your username is taken restart and try another username
2. Once you begin type:
	/set realname [Your name] *enter*
	/set email [Your Email] *enter*
3. You can use the purple bar across the bottom to issue commands and talk. 
      When you start typing, this bar is automatically activated, to finish what
       you type use return.
	
4. There are many commands you can issue from here. But these are the most important:
	/whois [name] - displays the person's info
	/set [variable] [string] - sets a variable
	/quit - quits
	</pre>

	<h2>3. Purchasing Cards</h2>
	<pre>
1. You will notice in the top-right corner a box with your name and how much
       money you have under it. This is how much money you have
2. Along the bottom are products you can purchase with the price of each product.
	-Middle-Click on one of these to purchase it
	-This will pop-up a display of the cards that the pack contained
	-To look at a card closely mouse over it and hold SHIFT
	-Once done looking at your cards press ESC to close the pop-up
	-The Cards will be added to your Library, which is available from Ctrl-B
3. By pressing Ctrl-B you get a list of all the cards available in the game
	-You can move through the pages with a mouse wheel or PgUp PgDn
	-Cards that you own have pictures
	-Cards that others have for sale have a price on them
	-To Purchase a card from some one else right-click on the card, then press BUY CARD
	-To put a card that you own up for sale, mouse over the card and press Ctrl-S. 
     To Remove from sale, press Ctrl-W
	</pre>

	<h2>4. Making A Deck</h2>
	<pre>
1. Type "/newdeck [deckname]" and press Enter
2. Right Click on Black Space then click Select Deck
3. Select Your Deck from the list
4. Press Ctrl-B to open your Library
5. Browse to the card you wish to add and middle-click to add it
6. To remove a card, left-click on it
7. Once finished, check its legality by right click on your deck menu and
   selecting "Check Legality"
8. Press Esc to close the deck menu
	</pre>

	<h2>5. Playing a Game</h2>
	<pre>
1. Click on a table
2. Middle-Click on the Table name
3. When the game starts, draw 7 cards by right-clicking on your deck and chosing "Draw 7 Cards"
4. At this point, obeying rules is UP TO THE PLAYERS
5. To Tap or Untap, middle-click on the card
6. To Play a card from hand, left-click on the card.
7. To Attach one card to another hold control while dragging it and move it to the other card
8. To end your turn press Ctrl-E
9. To change your life number type [New Life Number]
10. To end a game the winner types "/win" and the loser types "/ok"
	</pre>

    <hr>
    <address>Aaron</address>
<!-- Created: Thu Jan 30 12:51:11 EET 2003 -->
<!-- hhmts start -->
Last modified: Thu Jan 30 13:06:28 EET 2003
<!-- hhmts end -->
  </body>
</html>

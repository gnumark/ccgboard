<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
  <head>
    <title>Generic Collectible Card Game</title>
    <link href="default.css" rel="stylesheet" type="text/css">
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  </head>
<?
// Return list of files matching regular expression (without //).
function FilesMatching($dir,$rexp)
{
	$ret=array();

	$d=@opendir($dir);
	if($d)
		while (($f = readdir($d))!==false)
		{
			if(preg_match("/".$rexp."/",$f))
				array_push($ret,$f);
		}

  sort($ret);

	return $ret;
}

function FindFile($pattern)
{
  $f=FilesMatching(".",$pattern);
  rsort($f);
  return $f[0];
}

function FindFileDir($dir,$pattern)
{
  $f=FilesMatching($dir,$pattern);
  rsort($f);
  return $f[0];
}

function LinkTo($pattern)
{
	$f=FindFile($pattern);
	if($f=="")
		echo "<font color=red>UNAVAILABLE</font>\n";
	else
		echo "<a href=\"$f\"><tt>$f</tt></a>\n";
}

function LinkToDir($dir,$pattern)
{
	$f=FindFileDir($dir,$pattern);
	if($f=="")
		echo "<font color=red>UNAVAILABLE</font>\n";
	else
		echo "<a href=\"$dir/$f\"><tt>$f</tt></a>\n";
}

?>
  <body>
	  <center>
		<a href="modules/"><img alt="Gccg" class="photo" src="logo.png"></a>
	  </center>
	  <img class="photo" src="it.jpg"> <strong>Versione italiana disponibile <a href="index_it.php">qui</a></strong><br>
	  <img class="photo" src="de.jpg"> <strong>Die deutsche Version gibts <a href="http://gccg.GandalfsWelt.de">hier</a></strong><br>
	  <img class="photo" src="sp.jpg"> <strong>Preguntas frecuentes <a href="faq_es.php">aqui</a></strong><br>
  <p>

  <h1>News</h1>
  Join the Gccg 2 <a href="http://gccg.sourceforge.net/gccg2/">project</a>!
  <p>
  See the upcoming flagship <a href="http://gccg.sourceforge.net/gccg2/Werocia/index.html">game</a> of the Gccg project.

  <p><font color=red>Server available only for Mtg and Metw right now.</font>

  <p><font color=red>Those servers have also moved. If you cannot connect, please update your client.</font>

  <h1>Introduction</h1> Generic Collectible Card Game is a
	  multiplayer multiplatform implementation of a card game
	  engine. The card game engine is designed to be of general
	  purpose core for several modules each defining the game specific
	  behaviour. Players download a client for their platform and all
	  modules of interest. After launching the client for one of the
	  games, it connects to the central server of the game
	  chosen. When connected, all aspects of the collecting, trading
	  and playing are availble to the player. Here is a brief summary
	  of features:
	  <ul>
		<li>Deck editor including import and export from/to a text
		file. 
		<li>Fast game play: bureaucracy not implemented (on purpose).
	    <li>1-4 players.
		<li>You can watch games while not playing yourself.
		<li>Highly customizeable: macros and scripting
		language included.
		<li>Servers have a knowledge of several
		game formats (for example Type 1, Type 1.5, etc. in Mtg). Own
		game formats can be defined.
		<li>Sell cards by determining a price and the number of cards for
		  sale. Clients can see always the best offer.
		<li>Easy trading: create your want list and the server helps you
		  to find a trade.
		<li>Sealed deck games.
		<li>Export and import to/from existing deck formats.
	  </ul>

	<h1>History</h1>
		<ul>
		<li><strong>Jan 25th 2001</strong>: The project was founded.
		<li><strong>Jan 9th 2002</strong>: First complete game of Mtg was played.
		<li><strong>Sep 18th 2002</strong>: First complete game of Pokemon was played.
		<li><strong>Dec 4th 2002</strong>: First complete game of Metw was played.
		<li><strong>Jan 25th 2003</strong>: First public announcement on happypenguin.org.
		<li><strong>Jan 29th 2003</strong>: Project moved to gccg.sourceforge.net.
		<li><strong>Sep 26th 2003</strong>: First complete game of Lotr was played.
		<li><strong>Oct 26th 2004</strong>: Gccg II project started.
		</ul>

	<h1>Screenshots</h1>

	  Click to enlarge.<p>
<?
	$files=FilesMatching(".","thumb*.*\.jpg");
	foreach($files as $f)
	  echo "<a href=\"".preg_replace("/thumb/","screenshot",$f)."\"><img class=\"photo\" alt=\"screenshot\" src=\"$f\"></a>\n";
?>
	<p>
	<strong>NOTE: Card images are not included with the game.</strong>
	
	<h1>Installing</h1>

	  <h2>Linux</h2>

	  <ul>
		<li>Create a game directory<br>
		  <tt>mkdir gccg</tt><br>
		  <tt>cd gccg</tt><br>
		  
		<li>Download <? echo LinkToDir("modules","gccg-core.*");?> to
		  the game directory and unpack<br>
		  <tt>tar xzvf <? echo FindFileDir("modules","gccg-core.*");?></tt>
		
		<li>You can now use a package manager <tt>gccg_package</tt> to install the rest of
		  the game. You need to install at least packages
		  <tt>client</tt>, <tt>fonts</tt> and <tt>linux-i386</tt><br>
		  <tt>./gccg_package install client fonts linux-i386</tt>
		<li>You can list available modules<br>
		  <tt>./gccg_package status</tt>
		<li>Install game modules you wish to play<br>
		  <tt>./gccg_package install <em>game</em></tt><br>
		  where <tt><em>game</em></tt> is one of the <tt>mtg</tt>, <tt>pokemon</tt> or <tt>metw</tt>.
		  <li>Each game module have startup script with the same name as the module capitalized. You can launch the game using, i.e.<br>
		  <tt>./Mtg</tt>
		<li>To update all installed packages, say<br>
		  <tt>./gccg_package update</tt>
	  </ul>

	  <h3>Notes:</h3>
	  <ul>
	  <li>New Linux binaries are compiled against glibc 2.3. In practice this means
	  that older distribtions cannot use them any more.
	  Gccg binary version is tested on Debian sarge, Fedora Core 1, Mandrake 9.2 and
	  found functional. You can check if your distribution has glibc 2.3 from 
	  <a href="http://distrowatch.com">distrowatch.com</a>.
	  For older distributions you must compile from source.
	  </ul>

	  <h2>Mac OS X</h2>

	  To install Gccg on Mac OS X, you'll need some amount of familiarity 
	  with the Terminal app and the command line interface.

	  <ul>
		<li> Run the Terminal program (which is located in 
		  /Application/Utilities/).</li>
		<li>Create a folder to store Gccg in with<br>
		  <tt>mkdir gccg</tt></li>
		<li>Navigate to that folder with<br>
		  <tt>cd gccg</tt></li>
		<li>Download the <? echo LinkToDir("modules","gccg-core.*");?> module with <br>
		  <tt>curl -O http://gccg.sourceforge.net/modules/<? echo FindFileDir("modules","gccg-core.*");?></tt></li>
		<li>Decompress the file you just downloaded with<br>
		  <tt>tar xzvf <? echo FindFileDir("modules","gccg-core.*");?></tt></li>
		<li>Install the packages needed for the client:<br>
		  <tt>./gccg_package install client fonts macosx</tt></li>
		<li>Install game modules you wish to use:<br>
		  <tt>./gccg_package install <em>game</em></tt><br>
		  where <tt><em>game</em></tt> is <tt>mtg</tt>, <tt>pokemon</tt>, or <tt>metw</tt></li>
		<li>Run game using<br>
		  <tt>./<em>Game</em></tt><br>
		  where <tt><em>Game</em></tt> is <tt>Mtg</tt>, <tt>Pokemon</tt>, or <tt>Metw</tt>.
		<li>To update all installed packages, say<br>
		  <tt>./gccg_package update</tt>
	  </ul>
	  <h3>Notes:</h3>
	  <ul>
		<li>You can use alt+left click instead of middle click and ctrl+alt+left click instead of ctrl+middle click.</li>
		<li>If you wish, you can also type <tt>/bind /eval MouseMiddleClick()</tt> and then press a <em>key</em>. From now on, pressing the <em>key</em> is the same as middle clicking.</li>
        <li>Some of the special symbols cannot be produced right now in OS X. You can use <tt>/bindk</tt> command (see <tt>/help bindk</tt>) to bind those symbols to the keys. See <a href="manual/">manual</a> "Text formatting" section for more information about special symbols. 
	<br><strong>Example</strong>: type <tt>/bindk {R}</tt> and press enter. Then press some key combination. Now you can produce red mana symbol by pressing the key combination.
		<li> For 1024x768 resolution (or less): you don't have input line visible when using
		  1024x768 resolution. You can use full screen mode, see <a href="faq.php#sec1.2.">FAQ</a>.
		<li> If you'd like to create a shortcut to Gccg on your desktop, it's a 
		  little tricky, but possible. Open a new Terminal window, then go to 
		  "Save As." Make sure that "Execute this command" and "Execute command 
		  in a shell" boxes are selected. Type the following in the command box:<br>
		  <tt>~/gccg/<em>Game</em></tt><br> where you give a full
		  path to the script launhing the <em>game</em>.
		  Then save the <tt>.term</tt> file as whatever you like. Double-clicking this 
		  file will automatically execute the above command and open Gccg. 
		  Note that you can add parameters to the above command, like <tt>--user&nbsp;<em>nick</em></tt>
		  and <tt>--full</tt>.
	  </ul>

	  <h2>Source</h2>
	  <ul>
		<li>Make sure that you have libraries (includig headers)
		  <a href="http://www.libsdl.org/download-1.2.php">SDL</a>, 
		  <a href="http://www.libsdl.org/projects/SDL_image/">SDL_image</a>,
		  <a href="http://www.libsdl.org/projects/SDL_net/">SDL_net</a> and
		  <a href="http://www.libsdl.org/projects/SDL_ttf/">SDL_ttf</a>.
		<li>Install <? echo LinkToDir("modules","gccg-core.*");?>
		module as described above. Then, instead of binaries, install
		source code <br> <tt>./gccg_package install client fonts
		source</tt> <li>Compile<br> <tt>./configure</tt><br>
		<tt>make</tt><br>
		<li>Continue as above and install game modules.
	  </ul>
		Source code is also available <a><? echo LinkToDir("modules","gccg-source.*");?>here</a>.

	  <h3>Notes:</h3>
	  <ul>
		<li>Source does not currently compile with gcc v3.1. At least some versions have problems with maps involving templated member function pointers. However, usually you can install other compiler versions too in your system. Usually the extra compiler is named like <tt>gcc2</tt> or <tt>gcc-3.2</tt>. You may use non-default compiler by editing environment variables <tt>CC=gcc2</tt>, <tt>CXX=g++2</tt> and <tt>LD=g++2</tt> settings in <tt>Makefile</tt>.</li>
	  </ul>

	  <h2>Windows</h2>

		If you are interested in development, you should install Gccg with Cygwin as explained in the
	  <a href="cygwin.php">Cygwin guide</a>. Otherwise you can just download the <a href="gccg_install.zip">general windows installer</a>.
	   Unpack all files to your harddrive and then run the game installer named<p> <tt>Install <em>Game</em>.bat</tt><p>
		It downloads and installs all Gccg modules needed to play the particular <em>Game</em>. To play the game, launch
        <p><tt><em>Game</em>.bat</tt><p>
		and follow the instructions on screen.
		To update all modules installed later, launch the the update script called <p><tt>Update Everything.bat</tt><p>


	  <h2>Other</h2>
	  <ul>
	  <li>Not available for other platforms yet. Should compile easily on any platform with SDL.
	  </ul>

	  <h1>Documentation</h1>

	  Online help on IRCNet: <tt>/join #gccg</tt>.
	  <p>
	  <a href="faq.php">FAQ</a>
	  <p>
	  Browsable <a href="manual/">reference manual</a>.
	  
      <h1>Links</h1>
	  <h4>Gccg</h4>
	  <a href="http://sourceforge.net/forum/?group_id=72744">Gccg-Forum</a><br>
	  <a href="http://sf.net/projects/gccg/">SourceForge Project Page</a><br>
	  <a href="http://lists.sourceforge.net/lists/listinfo/gccg-devel">Mailing list</a><br>
	  <a href="http://gccg.sourceforge.net/misc/avatars.html">Avatars</a><br>

       	  <h4>Metw</h4>
	  <a href="http://www.meccg.net/netherlands/meccg/index.html?rules.html">Metw rules</a><br>

	  <h1>Authors</h1>
	  <h4>Code</h4>

	  <a href="http://www.akustiko.fi/~wigy/">Tommi Ronkainen</a>

	  <h4>Miscellaneous contributions</h4>

	  Antti Kantola, Aaron, Ilja Savolainen, Richard R. Buonanno, Napsu, Aleksi Keurulainen, Malakh Harbonah,
 Peter van Hardenberg, Jukka Karvonen, Antonio Cardenas, Jani Pietik�inen, FaUsT, Jonas Jermann, Pierre Bureau, Joshua Delahunty,
Petteri Nurmesj�rvi, Dyami Serna, Gerard Glaser, Bannor, Peter Minten, Dario Carlentini, Kuba Krchak, Dark, Grilled Fish, Kris Van Beurden, Ilkka Launonen.

	  <h4>Playtesting</h4>
	  Petteri Nurmesj�rvi, Ilja Savolainen, Veli Maaranen, Aleksi Keurulainen, Jukka Karvonen, Antti Kantola, Tommi Aittola, Lavapunk, Wim Heemskerk, Timo Tuomainen

	  <h4>Special thanks</h4>
	  Andre Arko and Tom Hackett (for providing me access to OS X).
	  <hr>
<A href="http://sourceforge.net"> <IMG class="photo" src="http://sourceforge.net/sflogo.php?group_id=72744&amp;type=5" width="210" height="62" border="0" alt="SourceForge.net Logo"></A>
<!-- Created: Fri Aug 23 17:23:44 EEST 2002 -->
<!-- hhmts start -->
Last modified: Mon Mar  1 10:48:29 EET 2004
<!-- hhmts end -->
	  </body>
</html>

Version 0.5
Bearbeitung: Gerard 'Gandalf' Glaser
http://www.GandalfsWelt.de
Anregungen/Fehler etc. bitte an: Gandalf@Gandalfs-Welt.de

Die Kartentexte wurden den originalen deutschen Karten entnommen (ohne Korrekturen und Klarstellungen), wodurch es zu Unterschiede zwischen deutschen und englischen Kartentexte kommen kann.
Vorzug sollten immer die englischen Texte haben, da diese vom Gro�teil der GCCG-Spieler benutzt werden.
Nachdem in dieser Version noch die �berschriften der englischen Karten genutzt werden, muss man sich f�r die englischen ODER deutschen Kartenbilder entscheiden.
Alle Kartennamen werden in Klammern mit den englischen Kartennamen wiederholt, um diese schneller in GCCG aufzufinden.

Derzeit komplett sind folgende Sets:
------------------------------------
The Wizards (einige Karten an Unterstuetzungen und viele Gefahren fehlen noch)
The Dragons 
Dark Minions
The White Hand
The Balrog
Against the Shadow

Alle Sets wurden nochmals auf Tipp-, Rechtschreib- und Symbolfehler �berpr�ft

ACHTUNG!!! Erst die Version 1.0 wird alle korrigierten (mit Erratas) Karten enthalten!!!

#!/usr/bin/perl

sub convert_symbols
{
	my $str=shift;
	
	$str=~s/L/{l}/g;
	$str=~s/F/{f}/g;
	$str=~s/R/{r}/g;
	$str=~s/G/{g}/g;
	$str=~s/W/{w}/g;
	$str=~s/P/{p}/g;
	$str=~s/D/{d}/g;
	$str=~s/S/{s}/g;
	$str=~s/1/{c}/g;
	$str=~s/2/{c}{c}/g;
	$str=~s/3/{c}{c}{c}/g;
	$str=~s/4/{c}{c}{c}{c}/g;
	$str=~s/5/{c}{c}{c}{c}{c}/g;
	$str=~s/6/{c}{c}{c}{c}{c}{c}/g;
	$str=~s/7/{c}{c}{c}{c}{c}{c}{c}/g;
	$str=~s/8/{c}{c}{c}{c}{c}{c}{c}{c}/g;
	$str=~s/9/{c}{c}{c}{c}{c}{c}{c}{c}{c}/g;

	return $str;
}

sub fix_names_etc()
{
	$title=~s/\s*$//;
	$title=~s/\s+$//;
	$color=~s/\s*$//;
	$color=~s/\s+$//;
	$type=~s/\s*$//;
	$type=~s/\s+$//;
	$hp=~s/\s*$//;
	$hp=~s/\s+$//;
	$type=~s/\s*$//;
	if($type=~m/(Stage \d+)\s*--\s*from\s+(.+)/)
	{
		$type=$1;
		$evolve=$2;
	}
	$type="Basic Energy" if $type eq "Energy";
	$type="Trainer - Stadium Card" if $type eq "Stadium Card";
	$type="Trainer - Pokemon Tool" if $type eq "Pokemon Tool";
	if($type=~m/(.*?) - (.*)/)
	{
		$subtype=$2;
		$type=$1;
	}
	
	$power=~s/^\"//;
	$power=~s/\"$//;
	$power=~s/\s+$//;
	$weakness=~s/^\s+//;
	$weakness=~s/\s+$//;
	$resistance=~s/^\s+//;
	$resistance=~s/\s+$//;
	$retreat=~s/^\s+//;
	$retreat=~s/\s+$//;
	$weakness="" if $weakness eq "none";
	$resistance="" if $resistance eq "none";
	$retreat="" if $retreat eq "none" or $retreat eq "0";
	$graphics=lc($title);
	$graphics=~s/[-()!\' :]//g;
	$graphics=~s/\[//g;
	$graphics=~s/\]//g;
	$graphics=~s/�/e/g;
    $rarity=~s/Uncommon/U/;
    $rarity=~s/Common/C/;
    $rarity=~s/Rare\s*/R/;
    $rarity=~s/R? ?- Holo/H/;
    $rarity=~s/R ?- ?Shining/S/;
    $rarity=~s/Energy\s*/E/;

    $text="" if $text eq "n/a";

    $weakness=convert_symbols($weakness);
    $retreat=convert_symbols($retreat);
	$resistance=~s/\[//g;
	$resistance=~s/\]//g;
    $resistance=~s/^([123456789LFRGWPDS]+)/convert_symbols($1)/e;
    $text=~s/\[([123456789LFRGWPDS]+)\]/"[".convert_symbols($1)."]"/eg;
    $text=~s/\b([LFRGWPDS]+)\b/convert_symbols($1)/eg;
    $text=~s/Unown \[\{(f|d)\}\]/"Unown [".uc($1)."]"/ge;
    $text=~s/Fire Energy/{r} Energy/g;
    $text=~s/Fighting Energy/{f} Energy/g;
    $text=~s/Water Energy/{w} Energy/g;
    $text=~s/Grass Energy/{g} Energy/g;
    $text=~s/Psychic Energy/{p} Energy/g;
    $text=~s/Lightning Energy/{l} Energy/g;

	$hp=~s/ HP$//;
	
    $count_graphics{$graphics}++;
    if($count_graphics{$graphics}>1)
    {
       $graphics.=$count_graphics{$graphics};
#       print STDERR "graphics/$dir/$graphics.jpg\n";
    }
}

sub show_card()
{
	fix_names_etc();
    print "    <card name=\"$title\" graphics=\"$graphics.jpg\" text=\"$text\">\n";
	print "       <attr key=\"color\" value=\"$color\"/>\n" if $color ne "";
	print "       <attr key=\"type\" value=\"$type\"/>\n";
	print "       <attr key=\"subtype\" value=\"$subtype\"/>\n" if $subtype ne "";
	print "       <attr key=\"rarity\" value=\"$rarity\"/>\n";
	print "       <attr key=\"card_number\" value=\"$card_number\"/>\n";
	print "       <attr key=\"evolve\" value=\"$evolve\"/>\n" if $evolve ne "";
	print "       <attr key=\"hp\" value=\"$hp\"/>\n" if $hp ne "";
	print "       <attr key=\"weakness\" value=\"$weakness\"/>\n" if $weakness ne "";
	print "       <attr key=\"resistance\" value=\"$resistance\"/>\n" if $resistance ne "";
	print "       <attr key=\"level\" value=\"$level\"/>\n" if $level ne "";
	print "       <attr key=\"retreat\" value=\"$retreat\"/>\n" if $retreat ne "";
	print "       <attr key=\"attack1\" value=\"$attack[1]\"/>\n" if $attack[1] ne "";
	print "       <attr key=\"attack2\" value=\"$attack[2]\"/>\n" if $attack[2] ne "";
	print "       <attr key=\"attack3\" value=\"$attack[3]\"/>\n" if $attack[3] ne "";
	print "       <attr key=\"attack4\" value=\"$attack[4]\"/>\n" if $attack[4] ne "";
	print "       <attr key=\"attack5\" value=\"$attack[5]\"/>\n" if $attack[5] ne "";
	print "       <attr key=\"attack6\" value=\"$attack[6]\"/>\n" if $attack[6] ne "";
	print "       <attr key=\"power\" value=\"$power\"/>\n" if $power ne "";
	print "       <attr key=\"rule\" value=\"$rule\"/>\n" if $rule ne "";

	print "    </card>\n\n";
	$title="";
	$text="";
	$type="";
	$subtype;
	$hp="";
	$color="";
	$weakness="";
	$resistance="";
	$retreat="";
	$level="";
	$attacks=0;
	$attack[1]="";
	$attack[2]="";
	$attack[3]="";
	$attack[4]="";
	$attack[5]="";
	$attack[6]="";
	$power="";
	$evolve="";
	$rule="";
}


# Show header

$a=<>;
chomp $a;
die "Spoiler header not found" if(not $a =~ m/^Set Name:\s+(.+)/);
$setname=$1;
$a=<>;
chomp $a;
die "Spoiler header not found" if(not $a =~ m/^Set Abbrev:\s+(.+)/);
$set=$1;
$a=<>;
chomp $a;
die "Spoiler header not found" if(not $a =~ m/^Set Dir:\s+(.+)/);
$dir=$1;

print "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n";
print "<!DOCTYPE ccg-setinfo SYSTEM \"../gccg-set.dtd\">\n";
print "<ccg-setinfo name=\"$setname\" dir=\"$dir\" abbrev=\"$set\" game=\"Pok�mon\">\n";
print "  <cards>\n\n";

# Parser
while(<>)
{
	chomp;

	s/^\s+$//;
	
 loop:
	next if m/^$/;
	
	if(m/^Name:\s+(.+)$/)
	{
		show_card() if($title ne "");
		$title=$1;
	}
	elsif(m/^Type:\s+(.+)$/)
	{
		$type=$1
	}
	elsif(m/^Card\s*\#:\s*([cC]ard\s*)?(\d+)\s*(of|\/)\s*\d+\s*$/)
	{
		$card_number=$2;
	}
	elsif(m/^Rarity:\s+(.+)$/)
	{
		$rarity=$1;
	}
	elsif(m/^Color:\s+(.+)$/)
	{
		$color=$1
	}
	elsif(m/^HP:\s+(.+)$/)
	{
		$hp=$1
	}
	elsif(m/^Weakness:\s+(.+)$/)
	{
		$weakness=$1
	}
	elsif(m/^Resistance:\s+(.+)$/)
	{
		$resistance=$1
	}
	elsif(m/^Retreat:\s+(.+)$/)
	{
		$retreat=$1
	}
	elsif(m/^Species:\s+(.+)$/)
	{
		$species=$1
	}
	elsif(m/^Level:\s+(.+)$/)
	{
		$level=$1
	}
	elsif(m/^Pokemon #:\s+(.+)$/)
	{
		$level=$1
	}
	elsif(m/^Power:\s+(.+?)\s*$/)
	{
		$power=$1;
		$power=~s/^\[//;
		$power=~s/\]$//;
        $text.=" " if $text ne "";
		$text.="Power: $power. ";
	next_text:
		$_=<>;
    	chomp;
		s/^\s+$//;
		if(m/^\s+(.+)$/)
		{
			$text.=" $1";
			goto next_text;
		}
		$text=~s/\"/&quot;/g;
		$text=~s/([^.])$/$1./;
		goto loop;
	}
	elsif(m/^Baby Form\s*:\s+(.+?)\s*$/)
	{
        $text.=" " if $text ne "";
		$text.="Baby form: $1";
	next_form:
		$_=<>;
    	chomp;
		s/^\s+$//;
		if(m/^\s+(.+)$/)
		{
			$text.=" $1";
			goto next_form;
		}
		$text=~s/\"/&quot;/g;
		$text=~s/([^.])$/$1./;
		goto loop;
	}
	elsif(m/^Attack:\s+(\[.+\]\s+(.+?)(\s+\(.*\))?)\s*$/)
	{
        $attacks=$attacks+1;
        $attack[$attacks]=$2;
        $text.=" " if $text ne "";
		$text.="Attack: $1";
	next_attack:
		$_=<>;
    	chomp;
	    s/^\s+$//;
		if(m/^\s+(.+)$/)
		{
			$text.=" $1";
			goto next_attack;
		}
		$text=~s/\"/&quot;/g;
		$text=~s/([^.])$/$1./;
		goto loop;
	}
	elsif(m/^Rule:\s*(.*)$/)
	{
		$rule="$1";
	next_rule:
		$_=<>;
    	chomp;
	    s/^\s+$//;
		if(m/^\s+(.+)$/)
		{
			$rule.=" $1";
			goto next_rule;
		}
		$rule=~s/\"/&quot;/g;
		$rule=~s/([^.])$/$1./;
		goto loop;
	}
	elsif(m/^Text:\s+(.+)$/)
	{
        $text.=" " if $text ne "";
		$text.="$1";
	next_text:
		$_=<>;
      	s/^\s+$//;
    	chomp;
		if(m/^\s+(.+)$/)
		{
			$text.=" $1";
			goto next_text;
		}
		$text=~s/\"/&quot;/g;
		$text=~s/([^.])$/$1./;
		goto loop;
	}
	else
	{
		die "Cannot parse '$_'";
	}
	
}


show_card() if($title ne "");

# Show footer
print "  </cards>\n";
print "</ccg-setinfo>\n";

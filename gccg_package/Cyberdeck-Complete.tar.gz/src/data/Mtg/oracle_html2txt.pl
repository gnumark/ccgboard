#!/usr/bin/perl

my $START_LINE="^<pre>";
my $END_LINE="^</pre>";

my $infile=shift;
my $outfile=shift;

if($infile eq "" || $outfile eq "") {
    print "usage: $0 <orcale html src> <oracle txt dst>\n";
    exit;
}

my $mode=0;
my $last_was_empty=0;

open(IN,"$infile") or die "$0: cannot open '$infile'";
open(OUT,">$outfile") or die "$0: cannot open '$outfile'";
while(<IN>)
{
    if($mode==0) {
	if(s/$START_LINE//) {
	    $mode=1;
	}
    }
    if($mode==1) {
	if(m/$END_LINE/) {
	    $mode=2;
	} else {
	    s/&nbsp;//g;
	    s/&\#8212;/--/g;
	    s/&\#8216;/\'/g;
	    s/&\#8217;/\'/g;
	    s/&\#8220;/\"/g;
	    s/&\#8221;/\"/g;
	    s/&amp;/&/g;
	    s/&lt;/</g;
	    s/&gt;/>/g;
	    s/^\s+//;
	    s/\s+$//;
	    s/<\/?b>//g;

	    if(m/(&\#\d+;)/) {
		print "'$_'";
		die "$0: unhandled special character $1"
	    }

	    if(!$last_was_empty || $_ ne "") {
		print OUT "$_\n";
		$last_was_empty=($_ eq "");
	    }
	}
    }
}
close(IN);
close(OUT);

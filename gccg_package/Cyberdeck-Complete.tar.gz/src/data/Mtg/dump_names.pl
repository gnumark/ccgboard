#!/usr/bin/perl -I ../../perl
#
# This utility generates the card rarity+name list from the existing XML data.
#
use gccg;

my $set=shift;
if($set eq "") {
    print "usage: $0 <set abbrev>\n";
    exit;
}

load_game("Mtg");

print "Set Name:   ",set_name($set),"\n";
print "Set Abbrev: $set\n";
print "Set Dir:    ",set_dir($set),"\n";
print "#########################\n";
print "#\n";
print "# List of cards ",set_first($set),"..",set_last($set),"\n";
print "#\n";
print "#########################\n";

for(cards_of_set($set)) {
  printf "%s %-32s %s\n",attr("rarity",$_),image($_),name($_);
}

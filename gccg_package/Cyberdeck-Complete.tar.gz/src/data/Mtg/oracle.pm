#!/usr/bin/perl

package oracle;

# Hash mapping card names to the number how many times they are
# encountered in the .list files.
my %cardnames; 
# Actual card data mapping card names to the attributes mapping to the
# values.
my %data;

# This function reads a single .list file and records card names.
sub read_cardfile {
    my $filename=shift;

    open(FILE,$filename);
    while(<FILE>) {
	next if(m/^Set (Name|Abbrev|Dir): (.+)/);
	next if m/^\s*\#/;
	next if m/^\s*$/;
	s/\s+$//;

	if(m/^(\S+)\s+(\S+)\s+(\S.*)/) {
	    $cardnames{$3}++;
	} else {
	    die "$0: strange line '$_' on card list file";
	}
    }
    close(FILE);
}

# This function scans all .list files and records all card names.
sub read_cardfiles {
    %cardnames=();
    opendir(DIR,".");
    for(grep {/\.list$/} readdir(DIR)) {
	read_cardfile($_);
    }
    closedir(DIR);
}

# This function fills module variables by reading 'oracle.txt' and all
# card name list files.
# Dump data while it is read, if called with parameter 1.
sub read_oracle {
    my $debug=shift;

    read_cardfiles();

    if($debug) {
	print "Known cards:\n";
	for(sort(keys(%cardnames))) {
	    print "'$_'\n";
	}
    }

    my $name="";      # Last card name found.
    my $str="";       # Current line read.
    my $mode="empty"; # Last entry found: 'empty', 'name', 'cost', 'type', 'powtough' or 'text'
    my $flip="";      # Set to the name of the main card, if we are
                      # handling flipped side of the card. 

    open(SPOILER,"cat special.txt oracle.txt|");
    while(<SPOILER>)
    {
	s/\s+$//;
	$str=$_;

	# Is it empty line?
	if($str=~m/^$/) {
	    $mode="empty";
	    next;
	}

	# Is it name? We must skip it, if it is just a text line
	# matching accidentally to the card name. That happens, when
	# card is a creature having e.g. Fear. We check that last line
	# wasn't Power/Toughness. Hmm. Perhaps more robust way is to
	# list cards explicitly.
	if($cardnames{$str} && $mode ne "powtough" && $mode ne "text") {
	    # Require empty line always.
	    die "$0: found card name '$str' after $mode line" if $mode ne "empty";

	    # Add flipcard info collected, if we had the flipped card previously.
	    if($flip ne "") {
		
		$data{$flip}{flipname}=$name;
		print "flipname='",$data{$flip}{flipname},"'\n" if $debug;
		
		for(keys(%{$data{$name}})) {
		    $data{$flip}{"flip$_"}=$data{$name}{$_};
		    print "flip$_='",$data{$flip}{"flip$_"},"'\n" if $debug;
		}

		delete $data{$name} if $name ne "Curse of the Fire Penguin";
	    }

	    # Start a new card.
	    $name=$str;
	    $mode="name";
	    $flip="";
	    print "\nname='$name'\n" if $debug && $flip eq "";
	    next;
	}
	
	# Is it cost?
	if($str=~m/^([,RGBUWXYZ0-9]+( \(half\))?( \/\/ )?)+$/i) {
	    # Cost follows always name.
	    die "$0: found cost '$str' after $mode line" if $mode ne "name" and $mode ne "empty";
	    $data{$name}{cost}=uc($str);
	    $mode="cost";
	    print "cost='",$data{$name}{cost},"'\n" if $debug && $flip eq "";
	    next;
	}

	# Is it card type?
	if($str=~m/^(((Basic|Artifact|Legendary|Snow-Covered|Land|Creature|Enchant|Enchantment|Sorcery|Instant|World|\/\/|Eaturecray|Summon The Biggest, Baddest, Nastiest,|Scariest Creature You\'ll Ever See|Equipment|Player|Summon .+?|Permanent|Interrupt|Enchant Forest|Enchant Mountain|Enchant Island|Enchant Swamp|Enchant Plains|Token) ?)+)( -- (.+))?$/) {
	    # Type follows always name or cost.
	    die "$0: found type '$str' after $mode line" if $mode ne "name" and $mode ne "cost" and $mode ne "empty";
	    $data{$name}{type}=$1;
	    $data{$name}{subtype}=$5 if $5 ne "";
	    $mode="type";
	    print "type='",$data{$name}{type},"'\n" if $debug && $flip eq "";
	    print "subtype='",$data{$name}{subtype},"'\n" if $debug && $flip eq "" && $5 ne "";
	    next;
	}

	# Is it power/toughness?
	if($str=~m/^(([*0-9]+?[-+])?([*0-9]+)(\{\^2\})?(\{1\/2\})?|\{1\/2\})\/(([*0-9]+?[-+])?([*0-9]+)(\{\^2\})?(\{1\/2\})?|\{1\/2\})$/) {
	    # power/toughness follows always type
	    die "$0: found powtough '$str' after $mode line" if $mode ne "type" and $mode ne "empty" and $name ne "Curse of the Fire Penguin";
	    $data{$name}{power}=$1;
	    $data{$name}{toughness}=$6;
	    $data{$name}{power}=~s/\{1\/2\}/�/;
	    $data{$name}{toughness}=~s/\{1\/2\}/�/;
	    print "power='",$data{$name}{power},"'\n" if $debug && $flip eq "";
	    print "toughness='",$data{$name}{toughness},"'\n" if $debug && $flip eq "";
	    $mode="powtough";
	    next;
	}

	# Is it flip mark? Then switch to flip card mode and add this
	# stuff to the main card, when the next title is found.
	if($str=~m/^-----?/) {
	    print "----- (flipped)\n" if $debug;
	    $flip=$name;
	    if($name ne "Curse of the Fire Penguin") {
		$name=<SPOILER>;
		$name=~s/\s+$//;
	    }
	    $mode="name";
	    next;
	}

	# It must be text then. Append it to the end of the current text.
	die "$0: scanning failed at '$str' (last recognized line was $mode)" if $mode ne "type" && $mode ne "powtough" && $mode ne "text" && $mode ne "empty";
	$str.="." if $str=~m/\w$/;

	# Some text formatting.
	$str=~s/(kicker)\s*--\s*(\S)/$1 -- $2/gi;
	# Convert mana or tap symbols.
	$str=~s/\b([0-9RGBUWXYZT]+)\b/convert_cost($1)/ge;

	# Restore false positive mana symbol cases.
	$str=~s/([.]){([RGBUWT])}/$1$2/g;
	$str=~s/{([XYZ0-9]+)}([-+])/$1$2/g;
	$str=~s/([-+.]){([XYZ0-9]+)}/$1$2/g;
	$str=~s/{([XYZ0-9]+)}(\/)/$1$2/g;
	$str=~s/(\/){([XYZ0-9]+)}/$1$2/g;
	$str=~s/{([XYZ0-9]+)}( is rolled| can\'t be| plus| target| damage| life| cards| creature| permanent| is the number)/$1$2/gi;
	$str=~s/(total of |equal to |can\'t be |prevent |deal |up to |distribute |sacrifices |becomes |size is |with |remove |scry |power |set to |puts |put |plus |rampage |bushido |fading |soulshift |amplify |modular ){([XYZ0-9]+)}/$1$2/gi;
	$str=~s/(and |where ){([XYZ0-9]+)}( is)/$1$2$3/gi;
	$str=~s/(between ){([XYZ0-9]+)}( and ){([XYZ0-9]+)}/$1$2$3$4/gi;
	
	# Fix special cases.
	$str=~s/{B}-I-N-{G}-O/B-I-N-G-O/g;

	# And append it to the existing text.
	$data{$name}{text}.=" " if $data{$name}{text} ne "";
	$data{$name}{text}.=$str;	    
	$mode="text";
	print "text='",$str,"'\n" if $debug && $flip eq "";
    }
    close(SPOILER);

    for(keys(%data)) {
	post_process($_);
    }
}

# This function converts spoiler mana cost string to Gccg tags.
sub convert_cost {
    my $cost=shift;

    $cost=~s/([RGBUWXYZT])/{$1}/g;
    $cost=~s/(\d+)/{$1}/g;

    return $cost;
}

# This function is called after all cards are read. This function
# handles any postprocessing needed for cards.
sub post_process {
    my $card=shift;

    # Determine color attribute
    if($data{$card}{type}=~ m/^(Legendary )?Artifact( Creature)?$/) {
	$data{$card}{color}="Artifact";
    } elsif($data{$card}{type} =~ m/^(Artifact )?(Legendary )?(Snow-Covered )?(Basic )?Land$/) {
	$data{$card}{color}="Land";
    } else {

	# Scan all color from cost
	my @colors;
	
	push @colors,"Black" if $data{$card}{cost}=~m/B/;
	push @colors,"Blue" if $data{$card}{cost}=~m/U/;
	push @colors,"Green" if $data{$card}{cost}=~m/G/;
	push @colors,"Red" if $data{$card}{cost}=~m/R/;
	push @colors,"White" if $data{$card}{cost}=~m/W/;

	# Handle zero cost special cards
	if(scalar @colors==0) {
	    push @colors,"Red" if($card eq "Crookshank Kobolds");
	    push @colors,"Red" if($card eq "Crimson Kobolds");
	    push @colors,"Red" if($card eq "Kobolds of Kher Keep");
	    push @colors,"Blue" if($card eq "Evermind");
	}

	# All non-artifact non-land cards should have color.
	die "no colors found in the cost for '$card' (cost='$data{$card}{cost}' type='$data{$card}{type}')" 
	    if scalar @colors==0;

	# Sort and join.
	$data{$card}{color}=join(" ",sort(@colors));
    }

    # Color must be defined for all cards.
    die "$0: card '$card' has no color" if $data{$card}{color} eq "";

    # Tokens have no cost
    delete $data{$card}{cost} if($data{$card}{type} eq "Token");

    # Fix cost symbols.
    if(exists $data{$card}{cost}) {
	$data{$card}{cost}=convert_cost($data{$card}{cost});
    }

    # Handle some special cases
    $data{$card}{text}="{T}: Add {B} to your mana pool." if $card =~ m/^(Snow-covered )?Swamp$/i;
    $data{$card}{text}="{T}: Add {G} to your mana pool." if $card =~ m/^(Snow-covered )?Forest$/i;
    $data{$card}{text}="{T}: Add {R} to your mana pool." if $card =~ m/^(Snow-covered )?Mountain$/i;
    $data{$card}{text}="{T}: Add {U} to your mana pool." if $card =~ m/^(Snow-covered )?Island$/i;
    $data{$card}{text}="{T}: Add {W} to your mana pool." if $card =~ m/^(Snow-covered )?Plains$/i;
    $data{$card}{type}="Basic Land" if $card eq "Swamp";
    $data{$card}{type}="Basic Land" if $card eq "Forest";
    $data{$card}{type}="Basic Land" if $card eq "Mountain";
    $data{$card}{type}="Basic Land" if $card eq "Island";
    $data{$card}{type}="Basic Land" if $card eq "Plains";

    $data{$card}{text}=~s/\{3\}\.\{1\}\(\{4\}\)/3.1(4)/ if $card eq "Bureaucracy";
    $data{$card}{text}=~s/1\/2/�/g if $card eq "Wet Willie of the Damned" || $card eq "Save Life" || $card eq "Saut�" || $card eq "Necro-Impotence" || $card eq "Letter Bomb" || $card eq "Fraction Jackson" || $card eq "Supersize" || $card eq "Bosom Buddy" || $card eq "Avatar of Me" || $card eq "Assquatch";
    $data{$card}{text}=~s/1\/2\*\{R\}/{r}/g if $card eq "Mons's Goblin Waiters";
    $data{$card}{text}=~s/1\/2/{half}/g if $card eq "Flaccify" || $card eq "Cheap Ass";
    $data{$card}{text}="{T}: Add {inf} to your mana pool. {1}{0}{0}: Add one mana of any color to your mana pool. You don't lose life due to mana burn." if $card eq "Mox Lotus";
    $data{$card}{text}=~s/\{B\}/B/g if $card eq "Ifh-B�ff Efreet";
    $data{$card}{text}=~s/\{([0-9]+)\}/$1/g if $card eq "Spark Fiend";

    $data{$card}{cost}="{1}{0}{0}{0}{0}{0}{0}" if $card eq "Gleemax";
    $data{$card}{cost}="{w}" if $card eq "Little Girl";

    $data{$card}{power}=~s/\{\^2\}/^2/ if $data{$card}{power}=~m/\{\^2\}/;
    $data{$card}{toughness}=~s/\{\^2\}/^2/ if $data{$card}{toughness}=~m/\{\^2\}/;
}

# Return the given attribute of the given card. If the attribute is
# not set (and is not 'text') this function dies.
sub get_attr {
    my $card=shift;
    my $attr=shift;
    die "$0: card '$card' does not exist"
	if not exists $data{$card};
    die "$0: attribute '$attr' does not exist for '$card'" 
	if not exists $data{$card}{$attr} and $attr ne "text";

    return $data{$card}{$attr};
}

# Return list of attributes (except 'text') for the given card.
sub attrs {
    my $card=shift;
    my @ret=keys(%{$data{$card}});

    die "$0: card '$card' does not exist"
	if not exists $data{$card};

    return sort grep {$_ ne "text"} @ret;
}
1;

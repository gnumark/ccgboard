#!/usr/bin/perl

use oracle;

my %age;
$age{"UG"}=16;
$age{"8E"}=32;
$age{"7E"}=25;
$age{"6E"}=19;
$age{"5E"}=12;
$age{"4E"}=7;
$age{"RV"}=4;
$age{"PM"}=-100;
$age{"P1"}=17;
$age{"P2"}=21;
$age{"P3"}=27;

my $infile=shift;
my $outfile=shift;

if($infile eq "--debug" && $outfile eq "") {
    oracle::read_oracle(1);
      exit;
}

if($infile eq "" || $outfile eq "") {
    print "usage: $0 <list file src> <xml file dst>\n";
    print "    or $0 --debug\n";
    exit;
}

my $set_abbrev;
my $set_name;
my $set_dir;
my $rarity;
my $graphics;
my $name;

oracle::read_oracle();

open(INFILE,$infile);
open(OUTFILE,">$outfile");

print OUTFILE "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n";
print OUTFILE "<!DOCTYPE ccg-setinfo SYSTEM \"../gccg-set.dtd\">\n";

while(<INFILE>) {
    if(m/^Set Name:\s+(.+)/) {
	$set_name=$1;
	next;
    }
    if(m/^Set Abbrev:\s+(.+)/) {
	$set_abbrev=$1;
	next;
    }
    if(m/^Set Dir:\s+(.+)/) {
	$set_dir=$1;
	if($age{$set_abbrev}) {
	    print OUTFILE "<ccg-setinfo name=\"$set_name\" dir=\"$set_dir\" abbrev=\"$set_abbrev\" game=\"Magic The Gathering\" age=\"$age{$set_abbrev}\">\n";
	} else {
	    print OUTFILE "<ccg-setinfo name=\"$set_name\" dir=\"$set_dir\" abbrev=\"$set_abbrev\" game=\"Magic The Gathering\">\n";
	}
	print OUTFILE "  <cards>\n";
	next;
    }
    next if m/^\s*\#/;
    next if m/^\s*$/;
    s/\s+$//;

    if(m/^(\S+)\s+(\S+)\s+(\S.*)/) {
	$rarity=$1;
	$graphics=$2;
	$name=$3;

	print OUTFILE "\n";
	print OUTFILE "    <card name=\"".enc($name)."\" graphics=\"$graphics\" text=\"".enc(oracle::get_attr($name,"text"))."\">\n";
	print OUTFILE "       <attr key=\"rarity\" value=\"$rarity\"/>\n";
	for(oracle::attrs($name)) {
	    print OUTFILE "       <attr key=\"$_\" value=\"".enc(oracle::get_attr($name,$_))."\"/>\n";

	}
	print OUTFILE "    </card>\n";

    } else {
	die "$0: strange line '$_' on card list file";
    }
}
close(INFILE);

print OUTFILE "\n";
print OUTFILE "  </cards>\n";
print OUTFILE "</ccg-setinfo>\n";

close(OUTFILE);

# This function encodes charcaters not allowed in attribute value.
sub enc {
    my $arg=shift;

    $arg=~s/&/&amp;/g;
    $arg=~s/</&lt;/g;
    $arg=~s/>/&gt;/g;
    $arg=~s/\"/&quot;/g;

    return $arg;
}

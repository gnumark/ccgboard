#!/usr/bin/perl
#
# Author: Jonas Jermann
#
# This is a script to fetch magic card images of a specifiable set from
# wizard's gatherer and additionally to create a set list file...
# The script creates a directory $set_abbrev and a list file $out_list

use LWP::UserAgent;
use Switch;
#use Text::Unidecode;
use strict;

# Main Program

# PREFERENCES

# Gatherer settings
my $filter_name="TimeSpiralBlock";
# Image Directory in the gatherer
my $image_dir="TSP";
# Set this to handle special rarities (check below)
my $special_trigger="Timeshifted";
my $normal_trigger="Time Spiral";
my $special_dir="TSB";
# Gccg settings
my $set_name="TimeSpiral";
my $set_abbrev="TS";
# Action settings
my $do_spoiler=1;
my $do_images=1;
my $do_list=1;

# PREFERENCES END


# GLOBAL VARIABLES

my $set_dir=$set_abbrev;
my $out_html="spoiler.html";
my $out_list="\L$set_abbrev.list";
my $cards=0;
my $nr=0;
my $nr_add=0;
my $nrimg=0;
my $nr_p=0;
my $nr_r=0;
my $nr_c=0;
my $nr_u=0;
my $nr_l=0;
my $nr_o=0;
my $basic_land=0;
my $basic_num=0;
my $special=0;
my $name;
my $image;
my $id;
my $rarity;
my $request;
my $response;
#try to download the image 3 times if it fails...
my $numtry=3;
my $url="http://ww2.wizards.com/gatherer/Index.aspx?setfilter=$filter_name\\&output=Spoiler";
my $ua = LWP::UserAgent->new();

# GLOBAL VARIABLES END


if ($do_spoiler) {
    GetSpoiler();
}

open(IN,"$out_html") || die "Can't open $out_html: $!\n";
if ($do_list) {
    open(OUT,">$out_list") || die "Can't open $out_list for writing: $!\n";
}
if ($do_images) {
    unless (-d $set_abbrev) {
        mkdir("$set_abbrev", 0755) || die "Can't create $set_abbrev: $!\n";
    }
}

if ($do_list) {
    putListHeader();
}

print "Parsing the downloaded html spoiler...\n";

while(<IN>) {
    # Grab how much cards we should find
    if (/>([0-9]*) Cards Found<\/span>/) {
        $cards=$1;
    }
    if (/CardDetails.aspx\?\&amp/) {
        if (ParseLine()) {
            if ($do_images) {
                GetImage();
            }
            if ($do_list) {
                putListEntry();
            }
        }
    } elsif (/CardDetails.aspx/ && $basic_land) {
        if (ParseBasicLandLine()) {
            if ($do_images) {
                GetImage();
            }
            if ($do_list) {
                putListEntry();
            }
        }
    }
}

PrintSummary();

close(IN);
if ($do_list) {
    close(OUT);
}
#unlink($out_html);



# Subroutines

# Get the html spoiler
sub GetSpoiler {
    print "Accessing $url (html spoiler)...\n";
    $request = HTTP::Request->new('GET', $url);
    $response = $ua->request($request,$out_html);

    if ( $response->is_error() ) {
        die "  => FAILED (Error-Code: ", $response->code() , " Error-Message: ", $response->message() , ")\n";
    } else {
        print "  => OK\n";
    }
}

# Parse a card entry
sub ParseLine {
    if (/^.*id=([0-9]*).*<b>(.*)<\/b>.*alt='(.*) \(([a-zA-Z])[a-zA-Z]*\).*$/) {
        $id=$1;
        $name=$2;
        my $set=$3;
        $rarity=$4;

        # Reset the basic land flag
        $basic_land=0;
        $basic_num=0;

        # Hack for special timespiral rarities
        if ($set=~/$special_trigger/) {
            $special=1;
        } elsif ($set=~/$normal_trigger/) {
            $special=0;
        } elsif ($name eq "Forest" || $name eq "Mountain" || $name eq "Plains" || $name eq "Island" || $name eq "Swamp") {
            $basic_land=1;
            $special=0;
        } else {
            $special=1;
        }

        if ($special) {
            $rarity="P";
        }

        # Basic Lands...
        if ($rarity eq "B") {
            $rarity="L";
        }

        $nr++;
        switch($rarity) {
            case "R" { $nr_r++; }
            case "U" { $nr_u++; }
            case "C" { $nr_c++; }
            case "L" { $nr_l++; }
            case "P" { $nr_p++; }
            else     { $nr_o++; }
        }

        # Card Name changes
        $image=$name;

        # Image Name changes
        $image=~s/�/AE/g;
        $image=~s/�/ae/g;
        $image=~s/�/a/g;
        #$image=unidecode("$image");
        $image=~s/'//g;
        $image=~s/,//g;
        $image=~s/\.//g;
        #$image=~s/-/_/g;
        $image=~s/ \/\/ / /g;
        $image=~s/ //g;
        $image="$image.jpg";

        return 1;
    } else {
        return 0;
    }
}

# Parse a basic land card entry
sub ParseBasicLandLine {
    if (/^.*id=([0-9]*).*alt='(.*) \(([a-zA-Z])[a-zA-Z]*\).*$/) {
        $id=$1;
        my $set=$2;
        $rarity=$3;

        # Hack for special timespiral rarities
        if ($set=~/$normal_trigger/ && $rarity eq "B") {
            $rarity="L";
        } else {
            return 0;
        }

        if ($basic_num) {
            $basic_num++;
            $nr_add++;
            $nr_l++;
            $image="$name$basic_num.jpg";
            return 1;
        } else {
            $basic_num++;
            return 0;
        }
    } else {
        return 0;
    }
}

# Save the images
sub GetImage {
    print "  $name ($image): ";

    my $try=0;
    my $imgurl;
    do {
        if ($special) {
            $imgurl="http://resources.wizards.com/Magic/Cards/$special_dir/en-us/Card$id.jpg";
        } else {
            $imgurl="http://resources.wizards.com/Magic/Cards/$image_dir/en-us/Card$id.jpg";
        }
        $request = HTTP::Request->new('GET', $imgurl);
        $response = $ua->request($request,"$set_abbrev/$image");
        $try++;
    } while ($response->is_error() && $try < $numtry);

    if ($response->is_error()) {
        print "FAILED (Error-Code: ", $response->code() , " Error-Message: ", $response->message() , ")\n";
    } else {
        $nrimg++;
        print "OK\n";
    }
}

# Make an entry in our list file
sub putListEntry() {
    printf OUT "%s %s %30s\n", $rarity, $image, $name;
}

sub putListHeader() {
    print OUT "Set Name:   $set_name\n";
    print OUT "Set Abbrev: $set_abbrev\n";
    print OUT "Set Dir:    $set_dir\n\n";
}

sub PrintSummary() {
    my $total=$nr+$nr_add;
    print  "\nSummary:\n";
    print  "  $nr / $cards different cards found\n";
    print  "  $nr_add additional basic lands found\n";
    print  "  => $total cards found\n";
    printf "      %3i / %3i rares\n", $nr_r, $total;
    printf "      %3i / %3i uncommons\n", $nr_u, $total;
    printf "      %3i / %3i commons\n", $nr_c, $total;
    printf "      %3i / %3i lands\n", $nr_l, $total;
    printf "      %3i / %3i specials\n", $nr_p, $total;
    printf "      %3i / %3i others\n", $nr_o, ,$total;
    print  "  $nrimg / $total cards downloaded\n";
}





#!/usr/bin/perl

use HTML::TreeBuilder;
use warnings;

sub getAttr {
    my $attr="";
    if ($_[0]=~/([0-9]+) Mana/) {
        $attr="$1";
    } elsif ($_[0]=~/Red Mana/) {
        $attr="R";
    } elsif ($_[0]=~/Blue Mana/) {
        $attr="U";
    } elsif ($_[0]=~/White Mana/) {
        $attr="W";
    } elsif ($_[0]=~/Black Mana/) {
        $attr="B";
    } elsif ($_[0]=~/Green Mana/) {
        $attr="G";
    } elsif ($_[0]=~/X Mana/) {
        $attr="X";
    } elsif ($_[0]=~/Tap/) {
        $attr="T";
    } else {
        print STDERR "Unknown attribute: $_[0]\n!";
    }
    return $attr;
}

sub fixName {
    my $string=$_[0];
    $string=~s/[^[:ascii:]����������������������������������������������]//g;  # � out!
    $string=~s/ \./\./g;
#    $string=~s/([^ ])-/$1 -/g;
#    $string=~s/-([^ ])/- $1/g;
    $string=~s/\.\./\./g;
    return $string;
}

sub parseName {
    $name=fixName($_[0]->as_text());
#    $name=~s/ - /-/g;
    return $name;
}
sub parseCost {
    my $cost="";
    my $attr;

    for my $entry ($_[0]->look_down("_tag","img")) {
        $attr=getAttr($entry->attr('alt'));
        $cost="$cost$attr";
    }
    
    return $cost;
}
sub parseType {
    return fixName($_[0]->as_text());
}
sub parseRules {
    my $string;

    for my $entry ($_[0]->look_down("_tag","img")) {
        $entry->replace_with(getAttr($entry->attr('alt')));
    }
# Uncomment this to remove reminder text
#    for my $entry ($_[0]->look_down("_tag","i")) {
#        $entry->replace_with("");
#    }
    for my $entry ($_[0]->look_down("_tag","br")) {
        $entry->replace_with(". ");
    }

    return fixName($_[0]->as_text());
}
sub parsePow {
    return fixName($_[0]->as_text());
}
sub parseTough {
    return fixName($_[0]->as_text());
}
sub parsePrint {
    return fixName($_[0]->as_text());
}


my $ARGC = scalar(@ARGV);
if ($ARGC == 0) {
    die "Usage: $0 <spoiler.html> <oracle.txt>\n";
} elsif ($ARGC == 1) {
    open(OUT,">/dev/stdout");
} else {
    open(OUT,">$ARGV[1]");
}
my $tree=HTML::TreeBuilder->new;
$tree->parse_file("$ARGV[0]");
my @anchors = $tree->look_down("_tag","table","id","_gridResults");

for my $card ($anchors[0]->look_down("_tag","tr")) {
    my @elements=$card->look_down("_tag","td");
    my $nr=0;
    my $name="";
    my $cost;
    my $type;
    my $rules="";
    my $pow;
    my $tough;
    my $print;

    foreach my $element (@elements) {
        $element=$element->find('font');
        if ($nr == 0) {
            $name  = parseName($element);
        } elsif ($nr == 1) {
            $cost  = parseCost($element);
        } elsif ($nr == 2) {
            $type  = parseType($element);
        } elsif ($nr == 3) {
            $rules = parseRules($element);
        } elsif ($nr == 4) {
            $pow   = parsePow($element);
        } elsif ($nr == 5) {
            $tough = parseTough($element);
        } elsif ($nr == 6) {
            $print = parsePrint($element);
        }
        $nr++;
    }


    if ($name) {
        print OUT "$name\n";
        if ($cost) {
            print OUT "$cost\n";
        }
        if ($type) {
            print OUT "$type\n";
        }
        if ($pow && $tough) {
            print OUT "$pow/$tough\n";
        }
        print OUT "$rules\n\n";
    }
}

$tree = $tree->delete;
if ($ARGC>1) {
    close(OUT);
}

#!/usr/bin/perl

if($#ARGV < 0)
{
	print "usage: $0 <game> <files>...\n";
	exit;
}

if($ARGV[0] eq "mtg")
{
	$Width=210;
	$Height=295;
}
elsif($ARGV[0] eq "pokemon")
{
	$Width=238;
	$Height=328;
}
elsif($ARGV[0] eq "metw")
{
	$Width=420;
	$Height=590;
}
elsif($ARGV[0] eq "lotr")
{
	$Width=235;
	$Height=328;
}
else
{
	die "$0: unknown game $ARGV[0]";
}

print "Game $ARGV[0]\n";
print "Image size ${Width}x${Height}\n";

shift @ARGV;

foreach $f (@ARGV)
{
	print "Converting $f\n";
	rename($f,"temporary.jpg");
	system("convert -geometry '${Width}x${Height}!' temporary.jpg \"$f\"");
	unlink("temporary.jpg");
}

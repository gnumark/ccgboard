#!/usr/bin/perl

$count=0;
$fail=0;

sub stripper
{
	my $file=shift;

	$file=~s/(\.full)?\.jpg$//i;
	$file=~s|\./||;
	$file=~s/[^a-zA-Z0-9]//g;
	return lc($file);
}

if($#ARGV < 1)
{
	print "usage: $0 <spoiler xml> <dir>\n";
	exit;
}

$dir=$ARGV[1];
mkdir($dir);

open(F,$ARGV[0]) or die "$0: cannot open $ARGV[0]";
while(<F>)
{
	chomp;
	if(m/<card name=\"(.+?)\" graphics=\"(.+?)\"/)
	{
		$grp=$2;
		$grp2name{$grp}=$1;
		$g=stripper($grp);
		$grp2stripped{$grp}=$g;
#		print "$1: $2: $g\n";
	}
}
close(F);

open(D,"find .|");
while(<D>)
{
	chomp;
	$g=$_;
	if($g ne ".")
	{
		$stripped2file{stripper($_)}=$g;
	}
}
close(D);

for(sort keys(%grp2name))
{
	$grp=$_;
	$name=$grp2name{$grp};
	$stripped=$grp2stripped{$grp};
	$file=$stripped2file{$stripped};
	if($file ne "")
	{
		$count++;
		$renamed{$stripped}=1;
		$file=~s/\"/\\\"/g;
		system("cp \"$file\" \"$dir/$grp\"");
#		print "cp \"$file\" -> \"$dir/$grp\"\n";
	}
	else
	{
		$fail++;
		print "No image for: $_\n";
	}
}

print "$count files successfully renamed, $fail files missing.\n";

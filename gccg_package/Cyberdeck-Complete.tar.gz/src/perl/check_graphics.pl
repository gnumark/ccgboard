#!/usr/bin/perl

while(<>)
{
	chomp;
	if(m/<ccg-setinfo name=".+?" dir="(.+?)"/)
	{
		$dir="graphics/Metw/$1";
	}

	if(m/<card name="([^\"]+)" graphics="([^\"]+)"/)
	{
		if(not -e "$dir/$2")
		{
			print "No graphics for $1 ($2)\n";
		}
	}
}
